﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace School_System
{
    public partial class SignUp : Form
    {

        public SignUp()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            string name = rjTextBox1.Texts;
            string mail = rjTextBox4.Texts;
            string p1 = rjTextBox2.Texts;
            if (p1 == rjTextBox3.Texts)
            {

                OTP oTP = new OTP(name, mail, p1);
                oTP.Show();
                this.Close();
            }
            else { MessageBox.Show("passwords are not matched"); }
        }





        private void label2_Click(object sender, EventArgs e)
        {
            LoginPage nu = new LoginPage();
            nu.Show();
            this.Close();
        }
    }
}
