﻿namespace School_System
{
    partial class OTP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            label2 = new Label();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjButton2 = new CustomControls.RJControls.RJButton();
            rjButton3 = new CustomControls.RJControls.RJButton();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Gainsboro;
            label1.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.SkyBlue;
            label1.Location = new Point(221, 141);
            label1.Name = "label1";
            label1.Size = new Size(141, 27);
            label1.TabIndex = 0;
            label1.Text = "Enter your otp";
            // 
            // rjTextBox1
            // 
            rjTextBox1.BackColor = Color.Gainsboro;
            rjTextBox1.BorderColor = Color.SkyBlue;
            rjTextBox1.BorderFocusColor = Color.FromArgb(128, 128, 255);
            rjTextBox1.BorderRadius = 10;
            rjTextBox1.BorderSize = 2;
            rjTextBox1.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox1.ForeColor = Color.DimGray;
            rjTextBox1.Location = new Point(221, 182);
            rjTextBox1.Margin = new Padding(4);
            rjTextBox1.Multiline = false;
            rjTextBox1.Name = "rjTextBox1";
            rjTextBox1.Padding = new Padding(10, 7, 10, 7);
            rjTextBox1.PasswordChar = false;
            rjTextBox1.PlaceholderColor = Color.DarkGray;
            rjTextBox1.PlaceholderText = "";
            rjTextBox1.Size = new Size(348, 35);
            rjTextBox1.TabIndex = 1;
            rjTextBox1.Texts = "";
            rjTextBox1.UnderlinedStyle = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.SkyBlue;
            label2.Location = new Point(221, 231);
            label2.Name = "label2";
            label2.Size = new Size(26, 22);
            label2.TabIndex = 4;
            label2.Text = "60";
            // 
            // rjButton1
            // 
            rjButton1.BackColor = Color.SkyBlue;
            rjButton1.BackgroundColor = Color.SkyBlue;
            rjButton1.BorderColor = Color.PaleTurquoise;
            rjButton1.BorderRadius = 8;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(590, 182);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(115, 35);
            rjButton1.TabIndex = 6;
            rjButton1.Text = "Submit";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += button1_Click;
            // 
            // rjButton2
            // 
            rjButton2.BackColor = Color.SkyBlue;
            rjButton2.BackgroundColor = Color.SkyBlue;
            rjButton2.BorderColor = Color.PaleTurquoise;
            rjButton2.BorderRadius = 8;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(454, 232);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(115, 35);
            rjButton2.TabIndex = 7;
            rjButton2.Text = "Send OTP";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += OTP_Load;
            // 
            // rjButton3
            // 
            rjButton3.BackColor = Color.SkyBlue;
            rjButton3.BackgroundColor = Color.SkyBlue;
            rjButton3.BorderColor = Color.PaleTurquoise;
            rjButton3.BorderRadius = 8;
            rjButton3.BorderSize = 0;
            rjButton3.FlatAppearance.BorderSize = 0;
            rjButton3.FlatStyle = FlatStyle.Flat;
            rjButton3.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton3.ForeColor = Color.White;
            rjButton3.Location = new Point(590, 231);
            rjButton3.Name = "rjButton3";
            rjButton3.Size = new Size(115, 36);
            rjButton3.TabIndex = 8;
            rjButton3.Text = "Back";
            rjButton3.TextColor = Color.White;
            rjButton3.UseVisualStyleBackColor = false;
            rjButton3.Click += button2_Click;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // OTP
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(800, 450);
            Controls.Add(rjButton3);
            Controls.Add(rjButton2);
            Controls.Add(rjButton1);
            Controls.Add(label2);
            Controls.Add(rjTextBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            MaximumSize = new Size(800, 450);
            MinimumSize = new Size(800, 450);
            Name = "OTP";
            StartPosition = FormStartPosition.CenterScreen;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private CustomControls.RJControls.RJTextBox rjTextBox1;
        private Label label2;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton rjButton2;
        private CustomControls.RJControls.RJButton rjButton3;
        private System.Windows.Forms.Timer timer1;
    }
}