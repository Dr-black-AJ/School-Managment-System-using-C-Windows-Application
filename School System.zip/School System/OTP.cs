﻿using CustomControls.RJControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System
{
    public partial class OTP : Form
    {
        public string otp;
        public string name;
        public string mail;
        public string password;
        public string id;
        public OTP()
        {
            InitializeComponent();

        }
        public OTP(string name1, string mail1, string password1)
        {
            InitializeComponent();
            name = name1;
            mail = mail1;
            password = password1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUp signUp = new SignUp();
            signUp.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rjTextBox1.Texts == otp)
            {
                ImportAcount();
            }
            else { rjTextBox1.BorderFocusColor = Color.Red; rjTextBox1.Focus(); }
        }
        private void ImportAcount()
        {
            
            SqlConnection con = new SqlConnection("Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
            con.Open();
            Random ran = new Random();
            int iid = ran.Next(10000);
            string id ="SC"+iid.ToString();
            createtable(id);
            SqlCommand cmd = new SqlCommand("INSERT INTO SCLOGIN(ID,SCNAME,EMAIL,PASSWORD) VALUES('" + id + "','" + name + "','" + mail + "','" + password + "');", con);
            int n = cmd.ExecuteNonQuery();
            if (n > 0)
            {
                Thread.Sleep(20);
                successmail(id);
                LoginPage nu = new LoginPage();
                nu.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Not Submited");
            }
            con.Close();
        }

        private void createtable(string id)
        {

            SqlConnection con = new SqlConnection("Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
            con.Open();
            SqlCommand cmd = new SqlCommand("create table "+id+ "s(SID int identity(1000,5) primary key,Simage image,Sname nvarchar(50),Sgardian  nvarchar(50),Smail nvarchar(50),Sphno numeric(18,0),Sgen nvarchar(50),Sclass numeric(18,0),Ssec nchar(10),Sroll numeric(18,0),Sbod date,Ben numeric(18,0),Eng numeric(18,0),Math numeric(18,0),Bio numeric(18,0),Phy numeric(18,0),Che numeric(18,0),Geo numeric(18,0),His numeric(18,0),Com numeric(18,0),Dra numeric(18,0),Spo numeric(18,0),Total numeric(18,0));", con);
            cmd.ExecuteNonQuery();
            SqlCommand cmd1 = new SqlCommand("create table "+id+ "t(tid int identity(1000,5) primary key,timage image,tname nvarchar(50),tgen nvarchar(50),tmail nvarchar(50),tphno numeric(18,0),tsub nvarchar(50),tdoj date);", con);
            cmd1.ExecuteNonQuery();
            SqlCommand cmd3 = new SqlCommand("create table " + id + "ru5(Day nvarchar(50) primary key,p1 nvarchar(50),t1 nvarchar(50),p2 nvarchar(50),t2 nvarchar(50),p3 nvarchar(50),t3 nvarchar(50),p4 nvarchar(50),t4 nvarchar(50),p5 nvarchar(50),t5 nvarchar(50),p6 nvarchar(50),t6 nvarchar(50),p7 nvarchar(50),t7 nvarchar(50));", con);
            cmd3.ExecuteNonQuery();  
            SqlCommand cmd4 = new SqlCommand("create table " + id + "ru6(Day nvarchar(50) primary key,p1 nvarchar(50),t1 nvarchar(50),p2 nvarchar(50),t2 nvarchar(50),p3 nvarchar(50),t3 nvarchar(50),p4 nvarchar(50),t4 nvarchar(50),p5 nvarchar(50),t5 nvarchar(50),p6 nvarchar(50),t6 nvarchar(50),p7 nvarchar(50),t7 nvarchar(50));", con);
            cmd4.ExecuteNonQuery();
            SqlCommand cmd5 = new SqlCommand("create table " + id + "ru7(Day nvarchar(50) primary key,p1 nvarchar(50),t1 nvarchar(50),p2 nvarchar(50),t2 nvarchar(50),p3 nvarchar(50),t3 nvarchar(50),p4 nvarchar(50),t4 nvarchar(50),p5 nvarchar(50),t5 nvarchar(50),p6 nvarchar(50),t6 nvarchar(50),p7 nvarchar(50),t7 nvarchar(50));", con);
            cmd5.ExecuteNonQuery();
            SqlCommand cmd6 = new SqlCommand("create table " + id + "ru8(Day nvarchar(50) primary key,p1 nvarchar(50),t1 nvarchar(50),p2 nvarchar(50),t2 nvarchar(50),p3 nvarchar(50),t3 nvarchar(50),p4 nvarchar(50),t4 nvarchar(50),p5 nvarchar(50),t5 nvarchar(50),p6 nvarchar(50),t6 nvarchar(50),p7 nvarchar(50),t7 nvarchar(50));", con);
            cmd6.ExecuteNonQuery();
            SqlCommand cmd7 = new SqlCommand("create table " + id + "ru9(Day nvarchar(50) primary key,p1 nvarchar(50),t1 nvarchar(50),p2 nvarchar(50),t2 nvarchar(50),p3 nvarchar(50),t3 nvarchar(50),p4 nvarchar(50),t4 nvarchar(50),p5 nvarchar(50),t5 nvarchar(50),p6 nvarchar(50),t6 nvarchar(50),p7 nvarchar(50),t7 nvarchar(50));", con);
            cmd7.ExecuteNonQuery();
            SqlCommand cmd8 = new SqlCommand("create table " + id + "ru10(Day nvarchar(50) primary key,p1 nvarchar(50),t1 nvarchar(50),p2 nvarchar(50),t2 nvarchar(50),p3 nvarchar(50),t3 nvarchar(50),p4 nvarchar(50),t4 nvarchar(50),p5 nvarchar(50),t5 nvarchar(50),p6 nvarchar(50),t6 nvarchar(50),p7 nvarchar(50),t7 nvarchar(50));", con);
            cmd8.ExecuteNonQuery();
            SqlCommand cmd9 = new SqlCommand("insert into " + id + "ru10(Day) VALUES ('D1'),('D2'),('D3'),('D4'),('D5'),('D6');", con);
            cmd9.ExecuteNonQuery();
            SqlCommand cmd10 = new SqlCommand("insert into " + id + "ru9(Day) VALUES ('D1'),('D2'),('D3'),('D4'),('D5'),('D6');", con);
            cmd10.ExecuteNonQuery();
            SqlCommand cmd11 = new SqlCommand("insert into " + id + "ru8(Day) VALUES ('D1'),('D2'),('D3'),('D4'),('D5'),('D6');", con);
            cmd11.ExecuteNonQuery();
            SqlCommand cmd12 = new SqlCommand("insert into " + id + "ru7(Day) VALUES ('D1'),('D2'),('D3'),('D4'),('D5'),('D6');", con);
            cmd12.ExecuteNonQuery();
            SqlCommand cmd13 = new SqlCommand("insert into " + id + "ru6(Day) VALUES ('D1'),('D2'),('D3'),('D4'),('D5'),('D6');", con);
            cmd13.ExecuteNonQuery();
            SqlCommand cmd14 = new SqlCommand("insert into " + id + "ru5(Day) VALUES ('D1'),('D2'),('D3'),('D4'),('D5'),('D6');", con);
            cmd14.ExecuteNonQuery();
            con.Close();
        }

        //Send otp to user mail
        private int mailotp()
        {
            MailMessage message = new MailMessage();
            message.From = new MailAddress("xxxxx@gmail.com");
            message.To.Add(new MailAddress(mail));
            message.Subject = "Verification";
            message.Body = "Your otp is " + otp;
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("xxxxx@gmail.com", "App password from chrome");
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            try
            {
                smtp.Send(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("err: " + ex.Message);
            }
            return 0;
        }
        //mail school id and password if sucess
        private void successmail(string id)
        {
            MailMessage message = new MailMessage();
            message.From = new MailAddress("xxxxx@gmail.com");
            message.To.Add(new MailAddress(mail));
            message.Subject = "Verification";
            message.Body = "your school id is " + id + " and password is " + password;
            SmtpClient smtp = new SmtpClient("smtp.gmail.com");
            smtp.Port = 587;
            smtp.EnableSsl = true;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("xxxxx@gmail.com", "App password from chrome");
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            try
            {
                smtp.Send(message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("err: " + ex.Message);
            }
        }
        //OTP validation
        private void OTP_Load(object sender, EventArgs e)
        {
            rjButton2.Text = "Resend OTP";
            Random ran = new Random();
            int ootp = ran.Next(10000);
            otp = ootp.ToString();
            mailotp();
            sec = 60;
            timer1.Enabled = true;

        }
        public int sec;

        private void timer1_Tick(object sender, EventArgs e)
        {
            label2.Text = sec--.ToString();
            if (sec < 1)
            {
                timer1.Stop();
                Random ran = new Random();
                int ootp = ran.Next(10000);
                otp = ootp.ToString();
                label2.Text = "otp is expired";
            }
        }


    }
}
