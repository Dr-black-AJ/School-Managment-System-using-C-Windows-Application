﻿namespace School_System
{
    partial class Deshboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            rjButton7 = new CustomControls.RJControls.RJButton();
            rjButton4 = new CustomControls.RJControls.RJButton();
            rjButton3 = new CustomControls.RJControls.RJButton();
            rjButton2 = new CustomControls.RJControls.RJButton();
            rjButton1 = new CustomControls.RJControls.RJButton();
            panel1 = new Panel();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            rjButton5 = new CustomControls.RJControls.RJButton();
            guna2ShadowPanel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2ShadowPanel2
            // 
            guna2ShadowPanel2.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            guna2ShadowPanel2.BackColor = Color.Gainsboro;
            guna2ShadowPanel2.Controls.Add(rjButton5);
            guna2ShadowPanel2.Controls.Add(rjButton7);
            guna2ShadowPanel2.Controls.Add(rjButton4);
            guna2ShadowPanel2.Controls.Add(rjButton3);
            guna2ShadowPanel2.Controls.Add(rjButton2);
            guna2ShadowPanel2.Controls.Add(rjButton1);
            guna2ShadowPanel2.FillColor = Color.White;
            guna2ShadowPanel2.Location = new Point(-2, -16);
            guna2ShadowPanel2.Margin = new Padding(3, 4, 3, 4);
            guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            guna2ShadowPanel2.ShadowColor = Color.Black;
            guna2ShadowPanel2.Size = new Size(160, 717);
            guna2ShadowPanel2.TabIndex = 1;
            // 
            // rjButton7
            // 
            rjButton7.Anchor = AnchorStyles.Left;
            rjButton7.BackColor = Color.SteelBlue;
            rjButton7.BackgroundColor = Color.SteelBlue;
            rjButton7.BorderColor = Color.SteelBlue;
            rjButton7.BorderRadius = 3;
            rjButton7.BorderSize = 0;
            rjButton7.FlatAppearance.BorderSize = 0;
            rjButton7.FlatStyle = FlatStyle.Flat;
            rjButton7.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton7.ForeColor = Color.White;
            rjButton7.Location = new Point(16, 487);
            rjButton7.Margin = new Padding(3, 4, 3, 4);
            rjButton7.Name = "rjButton7";
            rjButton7.Size = new Size(123, 52);
            rjButton7.TabIndex = 6;
            rjButton7.Text = "Logout";
            rjButton7.TextColor = Color.White;
            rjButton7.UseVisualStyleBackColor = false;
            rjButton7.Click += rjButton7_Click;
            // 
            // rjButton4
            // 
            rjButton4.Anchor = AnchorStyles.Left;
            rjButton4.BackColor = Color.SteelBlue;
            rjButton4.BackgroundColor = Color.SteelBlue;
            rjButton4.BorderColor = Color.SteelBlue;
            rjButton4.BorderRadius = 3;
            rjButton4.BorderSize = 0;
            rjButton4.FlatAppearance.BorderSize = 0;
            rjButton4.FlatStyle = FlatStyle.Flat;
            rjButton4.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton4.ForeColor = Color.White;
            rjButton4.Location = new Point(16, 348);
            rjButton4.Margin = new Padding(3, 4, 3, 4);
            rjButton4.Name = "rjButton4";
            rjButton4.Size = new Size(123, 52);
            rjButton4.TabIndex = 3;
            rjButton4.Text = "Rotine";
            rjButton4.TextColor = Color.White;
            rjButton4.UseVisualStyleBackColor = false;
            rjButton4.Click += rjButton4_Click;
            // 
            // rjButton3
            // 
            rjButton3.Anchor = AnchorStyles.Left;
            rjButton3.BackColor = Color.SteelBlue;
            rjButton3.BackgroundColor = Color.SteelBlue;
            rjButton3.BorderColor = Color.SteelBlue;
            rjButton3.BorderRadius = 3;
            rjButton3.BorderSize = 0;
            rjButton3.FlatAppearance.BorderSize = 0;
            rjButton3.FlatStyle = FlatStyle.Flat;
            rjButton3.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton3.ForeColor = Color.White;
            rjButton3.Location = new Point(16, 270);
            rjButton3.Margin = new Padding(3, 4, 3, 4);
            rjButton3.Name = "rjButton3";
            rjButton3.Size = new Size(123, 52);
            rjButton3.TabIndex = 2;
            rjButton3.Text = "Result";
            rjButton3.TextColor = Color.White;
            rjButton3.UseVisualStyleBackColor = false;
            rjButton3.Click += rjButton3_Click;
            // 
            // rjButton2
            // 
            rjButton2.Anchor = AnchorStyles.Left;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton2.BackgroundColor = Color.SteelBlue;
            rjButton2.BorderColor = Color.SteelBlue;
            rjButton2.BorderRadius = 3;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(16, 196);
            rjButton2.Margin = new Padding(3, 4, 3, 4);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(123, 52);
            rjButton2.TabIndex = 1;
            rjButton2.Text = "Teacher";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // rjButton1
            // 
            rjButton1.Anchor = AnchorStyles.Left;
            rjButton1.BackColor = Color.SteelBlue;
            rjButton1.BackgroundColor = Color.SteelBlue;
            rjButton1.BorderColor = Color.SteelBlue;
            rjButton1.BorderRadius = 3;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(18, 122);
            rjButton1.Margin = new Padding(3, 4, 3, 4);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(123, 52);
            rjButton1.TabIndex = 0;
            rjButton1.Text = "Student";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // panel1
            // 
            panel1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox1);
            panel1.Location = new Point(164, 4);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(1098, 680);
            panel1.TabIndex = 2;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 28.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(514, 51);
            label1.Name = "label1";
            label1.Size = new Size(0, 54);
            label1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            pictureBox1.Image = Properties.Resources.Screenshot_2023_04_10_153753;
            pictureBox1.Location = new Point(235, 179);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(816, 434);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // rjButton5
            // 
            rjButton5.Anchor = AnchorStyles.Left;
            rjButton5.BackColor = Color.SteelBlue;
            rjButton5.BackgroundColor = Color.SteelBlue;
            rjButton5.BorderColor = Color.SteelBlue;
            rjButton5.BorderRadius = 3;
            rjButton5.BorderSize = 0;
            rjButton5.FlatAppearance.BorderSize = 0;
            rjButton5.FlatStyle = FlatStyle.Flat;
            rjButton5.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton5.ForeColor = Color.White;
            rjButton5.Location = new Point(16, 418);
            rjButton5.Margin = new Padding(3, 4, 3, 4);
            rjButton5.Name = "rjButton5";
            rjButton5.Size = new Size(123, 52);
            rjButton5.TabIndex = 7;
            rjButton5.Text = "Fees";
            rjButton5.TextColor = Color.White;
            rjButton5.UseVisualStyleBackColor = false;
            rjButton5.Click += rjButton5_Click;
            // 
            // Deshboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Azure;
            ClientSize = new Size(1267, 686);
            Controls.Add(panel1);
            Controls.Add(guna2ShadowPanel2);
            Margin = new Padding(3, 4, 3, 4);
            MinimumSize = new Size(1285, 733);
            Name = "Deshboard";
            Text = "Deshboard";
            Load += Deshboard_Load;
            guna2ShadowPanel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private Panel panel1;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton rjButton7;
        private CustomControls.RJControls.RJButton rjButton4;
        private CustomControls.RJControls.RJButton rjButton3;
        private CustomControls.RJControls.RJButton rjButton2;
        private PictureBox pictureBox1;
        private Label label1;
        private CustomControls.RJControls.RJButton rjButton5;
    }
}