﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System
{
    public partial class Fees_gen : Form
    {

        public Fees_gen(string scname1, string name1, string cls1, string sc1, string roll1, string gen1)
        {
            scname = scname1; name = name1; cls = cls1; roll = roll1; sc = sc1; gen = gen1;
            InitializeComponent();
            date = DateTime.Now.ToString("dd/MM/yyyy  hh:mm:ss ");
        }
        public string date, scname, name, cls, sc, roll, gen;
        private void Fees_gen_Load(object sender, EventArgs e)
        {
            label8.Text = date;
            label13.Text = scname;
            label1.Text = name;
            label2.Text = cls;
            label3.Text = sc;
            label4.Text = roll;
        
            dataGridView1.Rows.Add("AcademicDevelopmentFee","100");
            dataGridView1.Rows.Add("AdmissionFee","50");
            dataGridView1.Rows.Add("BuldingFee","50");
            dataGridView1.Rows.Add("CourseFee","600");
            dataGridView1.Rows.Add("DevelopmentFee","60");
            dataGridView1.Rows.Add("LabFee","150");
            dataGridView1.Rows.Add("LibraryFee","50");
            dataGridView1.Rows.Add("SaraswateUtsab","100");
            dataGridView1.Rows.Add("SportFee","70");
            dataGridView1.Rows.Add("Total","1230");
           
            
        }
        private void Print(Panel pn1)
        {
            PrinterSettings ps = new PrinterSettings();
            panel1 = pn1;
            getprintarea(pn1);
            printPreviewDialog1.Document = printDocument1;
            printDocument1.PrintPage += new PrintPageEventHandler(printDocument1_PrintPage);
            printPreviewDialog1.ShowDialog();
        }

        private void getprintarea(Panel pn1)
        {
            bitmap = new Bitmap(pn1.Width, pn1.Height);
            pn1.DrawToBitmap(bitmap, new System.Drawing.Rectangle(0, 0, pn1.Width, pn1.Height));
        }

        private Bitmap bitmap;

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            System.Drawing.Rectangle pagearea = e.PageBounds;
            e.Graphics.DrawImage(bitmap, (pagearea.Width / 2) - (this.panel1.Width / 2), this.panel1.Location.Y);
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            toolTip1.SetToolTip(pictureBox2, "Print");
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Print(this.panel1);
        }


    }
}
