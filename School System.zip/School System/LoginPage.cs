﻿using CustomControls.RJControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            SignUp nu = new SignUp();
            nu.Show();
            this.Close();
        }


        private void rjButton1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM SCLOGIN WHERE ID='" + rjTextBox1.Texts + "' AND PASSWORD='" + rjTextBox2.Texts + "' ;", con);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                string scid = rjTextBox1.Texts;
                Deshboard deshboard = new Deshboard(scid);
                deshboard.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("account not exist");
            }
            reader.Close();
            con.Close();
        }

        private void rjTextBox1__TextChanged(object sender, EventArgs e)
        {

        }
    }
}
