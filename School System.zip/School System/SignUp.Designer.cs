﻿namespace School_System
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            rjTextBox4 = new CustomControls.RJControls.RJTextBox();
            label2 = new Label();
            rjTextBox3 = new CustomControls.RJControls.RJTextBox();
            label1 = new Label();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjTextBox2 = new CustomControls.RJControls.RJTextBox();
            pictureBox1 = new PictureBox();
            guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(rjTextBox1);
            guna2ShadowPanel1.Controls.Add(rjTextBox4);
            guna2ShadowPanel1.Controls.Add(label2);
            guna2ShadowPanel1.Controls.Add(rjTextBox3);
            guna2ShadowPanel1.Controls.Add(label1);
            guna2ShadowPanel1.Controls.Add(rjButton1);
            guna2ShadowPanel1.Controls.Add(rjTextBox2);
            guna2ShadowPanel1.FillColor = Color.SteelBlue;
            guna2ShadowPanel1.Location = new Point(384, -12);
            guna2ShadowPanel1.Margin = new Padding(3, 4, 3, 4);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 30;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(582, 629);
            guna2ShadowPanel1.TabIndex = 0;
            // 
            // rjTextBox1
            // 
            rjTextBox1.BackColor = Color.White;
            rjTextBox1.BorderColor = Color.White;
            rjTextBox1.BorderFocusColor = Color.FromArgb(128, 128, 255);
            rjTextBox1.BorderRadius = 15;
            rjTextBox1.BorderSize = 2;
            rjTextBox1.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox1.Location = new Point(114, 152);
            rjTextBox1.Margin = new Padding(5);
            rjTextBox1.Multiline = false;
            rjTextBox1.Name = "rjTextBox1";
            rjTextBox1.Padding = new Padding(11, 9, 11, 9);
            rjTextBox1.PasswordChar = false;
            rjTextBox1.PlaceholderColor = Color.DarkGray;
            rjTextBox1.PlaceholderText = "school  name";
            rjTextBox1.Size = new Size(363, 39);
            rjTextBox1.TabIndex = 1;
            rjTextBox1.Texts = "";
            rjTextBox1.UnderlinedStyle = false;
            // 
            // rjTextBox4
            // 
            rjTextBox4.BackColor = Color.White;
            rjTextBox4.BorderColor = Color.White;
            rjTextBox4.BorderFocusColor = Color.FromArgb(128, 128, 255);
            rjTextBox4.BorderRadius = 15;
            rjTextBox4.BorderSize = 2;
            rjTextBox4.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox4.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox4.Location = new Point(114, 214);
            rjTextBox4.Margin = new Padding(5);
            rjTextBox4.Multiline = false;
            rjTextBox4.Name = "rjTextBox4";
            rjTextBox4.Padding = new Padding(11, 9, 11, 9);
            rjTextBox4.PasswordChar = false;
            rjTextBox4.PlaceholderColor = Color.DarkGray;
            rjTextBox4.PlaceholderText = "email id";
            rjTextBox4.Size = new Size(363, 39);
            rjTextBox4.TabIndex = 2;
            rjTextBox4.Texts = "";
            rjTextBox4.UnderlinedStyle = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(215, 536);
            label2.Name = "label2";
            label2.Size = new Size(173, 20);
            label2.TabIndex = 7;
            label2.Text = "already have an account ";
            label2.Click += label2_Click;
            // 
            // rjTextBox3
            // 
            rjTextBox3.BackColor = SystemColors.Window;
            rjTextBox3.BorderColor = Color.White;
            rjTextBox3.BorderFocusColor = Color.FromArgb(128, 128, 255);
            rjTextBox3.BorderRadius = 15;
            rjTextBox3.BorderSize = 2;
            rjTextBox3.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox3.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox3.Location = new Point(114, 341);
            rjTextBox3.Margin = new Padding(5);
            rjTextBox3.Multiline = false;
            rjTextBox3.Name = "rjTextBox3";
            rjTextBox3.Padding = new Padding(11, 9, 11, 9);
            rjTextBox3.PasswordChar = true;
            rjTextBox3.PlaceholderColor = Color.DarkGray;
            rjTextBox3.PlaceholderText = "confirm password";
            rjTextBox3.Size = new Size(363, 39);
            rjTextBox3.TabIndex = 4;
            rjTextBox3.Texts = "";
            rjTextBox3.UnderlinedStyle = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Arial Rounded MT Bold", 36F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(148, 58);
            label1.Name = "label1";
            label1.Size = new Size(299, 70);
            label1.TabIndex = 1;
            label1.Text = "Welcome";
            label1.Click += label1_Click;
            // 
            // rjButton1
            // 
            rjButton1.BackColor = Color.Navy;
            rjButton1.BackgroundColor = Color.Navy;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 20;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.SteelBlue;
            rjButton1.Location = new Point(217, 460);
            rjButton1.Margin = new Padding(3, 4, 3, 4);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(171, 53);
            rjButton1.TabIndex = 4;
            rjButton1.Text = "Verify";
            rjButton1.TextColor = Color.SteelBlue;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjTextBox2
            // 
            rjTextBox2.BackColor = SystemColors.Window;
            rjTextBox2.BorderColor = Color.White;
            rjTextBox2.BorderFocusColor = Color.FromArgb(128, 128, 255);
            rjTextBox2.BorderRadius = 15;
            rjTextBox2.BorderSize = 2;
            rjTextBox2.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox2.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox2.Location = new Point(114, 275);
            rjTextBox2.Margin = new Padding(5);
            rjTextBox2.Multiline = false;
            rjTextBox2.Name = "rjTextBox2";
            rjTextBox2.Padding = new Padding(11, 9, 11, 9);
            rjTextBox2.PasswordChar = true;
            rjTextBox2.PlaceholderColor = Color.DarkGray;
            rjTextBox2.PlaceholderText = "new password";
            rjTextBox2.Size = new Size(363, 39);
            rjTextBox2.TabIndex = 3;
            rjTextBox2.Texts = "";
            rjTextBox2.UnderlinedStyle = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.pngtree;
            pictureBox1.Location = new Point(14, 16);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(363, 568);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // SignUp
            // 
            AcceptButton = rjButton1;
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(912, 589);
            Controls.Add(pictureBox1);
            Controls.Add(guna2ShadowPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(3, 4, 3, 4);
            MaximumSize = new Size(930, 636);
            MinimumSize = new Size(930, 636);
            Name = "SignUp";
            StartPosition = FormStartPosition.CenterScreen;
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Label label1;
        private CustomControls.RJControls.RJTextBox rjTextBox2;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJTextBox rjTextBox3;
        private PictureBox pictureBox1;
        private Label label2;
        private CustomControls.RJControls.RJTextBox rjTextBox4;
        private CustomControls.RJControls.RJTextBox rjTextBox1;
    }
}