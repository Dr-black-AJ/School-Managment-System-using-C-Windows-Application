﻿using CustomControls.RJControls;
using School_System.user_controls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System
{
    public partial class Deshboard : Form
    {
        public string scid;
        public Deshboard()
        {
            InitializeComponent();
        }
        public Deshboard(string id)
        {
            InitializeComponent();
            scid = id;
        }

        private void rjButton7_Click(object sender, EventArgs e)
        {
            LoginPage nu = new LoginPage();
            nu.Show();
            this.Close();
        }
        private void addUserControl(UserControl userControl, object sender)
        {
            rjButton1.BackColor = Color.SteelBlue;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton3.BackColor = Color.SteelBlue;
            rjButton4.BackColor = Color.SteelBlue;
            Button button = sender as Button;
            button.BackColor = Color.MidnightBlue;
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Clear();
            panel1.Controls.Add(userControl);
            userControl.BringToFront();
        }


        private void rjButton1_Click(object sender, EventArgs e)
        {

            Student student = new Student(scid);
            addUserControl(student, sender);
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            Teacher teacher = new Teacher(scid);
            addUserControl(teacher, sender);
        }

        private void rjButton3_Click(object sender, EventArgs e)
        {
            Result result = new Result(scid);
            addUserControl(result, sender);
        }

        private void rjButton4_Click(object sender, EventArgs e)
        {
            Routine routine = new Routine(scid);
            addUserControl(routine, sender);
        }
        private void Deshboard_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT SCNAME FROM SCLOGIN WHERE ID='" + scid + "';", con);
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                label1.Text = reader.GetValue(0).ToString();
                this.Text = reader.GetValue(0).ToString();
            }
            reader.Close();
            con.Close();
        }

        private void rjButton5_Click(object sender, EventArgs e)
        {
            Fees fees = new Fees(scid);
            addUserControl (fees, sender);
        }
    }
}
