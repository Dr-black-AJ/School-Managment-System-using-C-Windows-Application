﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System.user_controls
{
    public partial class Routine : UserControl
    {

        SqlConnection sqlcon = new SqlConnection(@"Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
        DataTable dt;
        SqlDataAdapter da;

        public Routine()
        {
            InitializeComponent();
        }
        public string scid;
        public Routine(string id)
        {
            InitializeComponent();
            scid = id;
        }

        private void Routine_Load(object sender, EventArgs e)
        {
            guna2ComboBox2.SelectedIndex = 0;
            fill_grid();
        }

        private void guna2ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            fill_grid();
        }
        public void fill_grid()
        {
            if (sqlcon.State == ConnectionState.Open)
            {
                sqlcon.Close();
            }
            sqlcon.Open();
            string c = guna2ComboBox2.SelectedItem.ToString();
            SqlCommand cmd = sqlcon.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from " + scid + "ru" + c + "";
            cmd.ExecuteNonQuery();
            dt = new DataTable();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            SqlCommandBuilder sqlBuilder = new SqlCommandBuilder(da);
            da.Update(dt);
            fill_grid();
        }
    }
}
