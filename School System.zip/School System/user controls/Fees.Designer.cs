﻿namespace School_System.user_controls
{
    partial class Fees
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            label1 = new Label();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjTextBox2 = new CustomControls.RJControls.RJTextBox();
            rjTextBox3 = new CustomControls.RJControls.RJTextBox();
            rjTextBox4 = new CustomControls.RJControls.RJTextBox();
            rjTextBox5 = new CustomControls.RJControls.RJTextBox();
            rjButton2 = new CustomControls.RJControls.RJButton();
            rjTextBox6 = new CustomControls.RJControls.RJTextBox();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // rjTextBox1
            // 
            rjTextBox1.Anchor = AnchorStyles.Left;
            rjTextBox1.BackColor = SystemColors.Window;
            rjTextBox1.BorderColor = Color.SteelBlue;
            rjTextBox1.BorderFocusColor = Color.MidnightBlue;
            rjTextBox1.BorderRadius = 5;
            rjTextBox1.BorderSize = 2;
            rjTextBox1.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox1.Location = new Point(107, 61);
            rjTextBox1.Margin = new Padding(4);
            rjTextBox1.Multiline = false;
            rjTextBox1.Name = "rjTextBox1";
            rjTextBox1.Padding = new Padding(10, 7, 10, 7);
            rjTextBox1.PasswordChar = false;
            rjTextBox1.PlaceholderColor = Color.DarkGray;
            rjTextBox1.PlaceholderText = "SID";
            rjTextBox1.Size = new Size(245, 35);
            rjTextBox1.TabIndex = 7;
            rjTextBox1.Texts = "";
            rjTextBox1.UnderlinedStyle = false;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 10.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(685, 36);
            label1.Name = "label1";
            label1.Size = new Size(78, 21);
            label1.TabIndex = 26;
            label1.Text = "Student";
            // 
            // rjButton1
            // 
            rjButton1.Anchor = AnchorStyles.Left;
            rjButton1.BackColor = Color.SteelBlue;
            rjButton1.BackgroundColor = Color.SteelBlue;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 5;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(107, 119);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(245, 36);
            rjButton1.TabIndex = 32;
            rjButton1.Text = "Find";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjTextBox2
            // 
            rjTextBox2.Anchor = AnchorStyles.Right;
            rjTextBox2.BackColor = SystemColors.Window;
            rjTextBox2.BorderColor = Color.SteelBlue;
            rjTextBox2.BorderFocusColor = Color.MidnightBlue;
            rjTextBox2.BorderRadius = 5;
            rjTextBox2.BorderSize = 2;
            rjTextBox2.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox2.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox2.Location = new Point(607, 272);
            rjTextBox2.Margin = new Padding(4);
            rjTextBox2.Multiline = false;
            rjTextBox2.Name = "rjTextBox2";
            rjTextBox2.Padding = new Padding(10, 7, 10, 7);
            rjTextBox2.PasswordChar = false;
            rjTextBox2.PlaceholderColor = Color.DarkGray;
            rjTextBox2.PlaceholderText = "NAME";
            rjTextBox2.Size = new Size(245, 35);
            rjTextBox2.TabIndex = 33;
            rjTextBox2.Texts = "";
            rjTextBox2.UnderlinedStyle = false;
            // 
            // rjTextBox3
            // 
            rjTextBox3.Anchor = AnchorStyles.Right;
            rjTextBox3.BackColor = SystemColors.Window;
            rjTextBox3.BorderColor = Color.SteelBlue;
            rjTextBox3.BorderFocusColor = Color.MidnightBlue;
            rjTextBox3.BorderRadius = 5;
            rjTextBox3.BorderSize = 2;
            rjTextBox3.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox3.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox3.Location = new Point(607, 330);
            rjTextBox3.Margin = new Padding(4);
            rjTextBox3.Multiline = false;
            rjTextBox3.Name = "rjTextBox3";
            rjTextBox3.Padding = new Padding(10, 7, 10, 7);
            rjTextBox3.PasswordChar = false;
            rjTextBox3.PlaceholderColor = Color.DarkGray;
            rjTextBox3.PlaceholderText = "CLASS";
            rjTextBox3.Size = new Size(245, 35);
            rjTextBox3.TabIndex = 34;
            rjTextBox3.Texts = "";
            rjTextBox3.UnderlinedStyle = false;
            // 
            // rjTextBox4
            // 
            rjTextBox4.Anchor = AnchorStyles.Right;
            rjTextBox4.BackColor = SystemColors.Window;
            rjTextBox4.BorderColor = Color.SteelBlue;
            rjTextBox4.BorderFocusColor = Color.MidnightBlue;
            rjTextBox4.BorderRadius = 5;
            rjTextBox4.BorderSize = 2;
            rjTextBox4.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox4.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox4.Location = new Point(607, 385);
            rjTextBox4.Margin = new Padding(4);
            rjTextBox4.Multiline = false;
            rjTextBox4.Name = "rjTextBox4";
            rjTextBox4.Padding = new Padding(10, 7, 10, 7);
            rjTextBox4.PasswordChar = false;
            rjTextBox4.PlaceholderColor = Color.DarkGray;
            rjTextBox4.PlaceholderText = "SECTION";
            rjTextBox4.Size = new Size(245, 35);
            rjTextBox4.TabIndex = 35;
            rjTextBox4.Texts = "";
            rjTextBox4.UnderlinedStyle = false;
            // 
            // rjTextBox5
            // 
            rjTextBox5.Anchor = AnchorStyles.Right;
            rjTextBox5.BackColor = SystemColors.Window;
            rjTextBox5.BorderColor = Color.SteelBlue;
            rjTextBox5.BorderFocusColor = Color.MidnightBlue;
            rjTextBox5.BorderRadius = 5;
            rjTextBox5.BorderSize = 2;
            rjTextBox5.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox5.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox5.Location = new Point(607, 437);
            rjTextBox5.Margin = new Padding(4);
            rjTextBox5.Multiline = false;
            rjTextBox5.Name = "rjTextBox5";
            rjTextBox5.Padding = new Padding(10, 7, 10, 7);
            rjTextBox5.PasswordChar = false;
            rjTextBox5.PlaceholderColor = Color.DarkGray;
            rjTextBox5.PlaceholderText = "ROLL";
            rjTextBox5.Size = new Size(245, 35);
            rjTextBox5.TabIndex = 36;
            rjTextBox5.Texts = "";
            rjTextBox5.UnderlinedStyle = false;
            // 
            // rjButton2
            // 
            rjButton2.Anchor = AnchorStyles.Bottom;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton2.BackgroundColor = Color.SteelBlue;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 5;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(439, 557);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(245, 36);
            rjButton2.TabIndex = 37;
            rjButton2.Text = "Generate Invoice";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // rjTextBox6
            // 
            rjTextBox6.Anchor = AnchorStyles.Right;
            rjTextBox6.BackColor = SystemColors.Window;
            rjTextBox6.BorderColor = Color.SteelBlue;
            rjTextBox6.BorderFocusColor = Color.MidnightBlue;
            rjTextBox6.BorderRadius = 5;
            rjTextBox6.BorderSize = 2;
            rjTextBox6.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox6.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox6.Location = new Point(607, 490);
            rjTextBox6.Margin = new Padding(4);
            rjTextBox6.Multiline = false;
            rjTextBox6.Name = "rjTextBox6";
            rjTextBox6.Padding = new Padding(10, 7, 10, 7);
            rjTextBox6.PasswordChar = false;
            rjTextBox6.PlaceholderColor = Color.DarkGray;
            rjTextBox6.PlaceholderText = "GENDER";
            rjTextBox6.Size = new Size(245, 35);
            rjTextBox6.TabIndex = 38;
            rjTextBox6.Texts = "";
            rjTextBox6.UnderlinedStyle = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Right;
            pictureBox1.BackColor = Color.LightSteelBlue;
            pictureBox1.Location = new Point(643, 76);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(177, 189);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 39;
            pictureBox1.TabStop = false;
            // 
            // Fees
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(pictureBox1);
            Controls.Add(rjTextBox6);
            Controls.Add(rjButton2);
            Controls.Add(rjTextBox5);
            Controls.Add(rjTextBox4);
            Controls.Add(rjTextBox3);
            Controls.Add(rjTextBox2);
            Controls.Add(rjButton1);
            Controls.Add(label1);
            Controls.Add(rjTextBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Fees";
            Size = new Size(1098, 680);
            Load += Notice_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private CustomControls.RJControls.RJTextBox rjTextBox1;
        private Label label1;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJTextBox rjTextBox2;
        private CustomControls.RJControls.RJTextBox rjTextBox3;
        private CustomControls.RJControls.RJTextBox rjTextBox4;
        private CustomControls.RJControls.RJTextBox rjTextBox5;
        private CustomControls.RJControls.RJButton rjButton2;
        private CustomControls.RJControls.RJTextBox rjTextBox6;
        private PictureBox pictureBox1;
    }
}
