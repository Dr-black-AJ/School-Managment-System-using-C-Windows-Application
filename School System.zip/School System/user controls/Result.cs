﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System.user_controls
{
    public partial class Result : UserControl
    {
        SqlConnection sqlcon = new SqlConnection(@"Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
        DataTable dt;
        SqlDataAdapter da;
        public Result(string id)
        {
            InitializeComponent();
            scid = id;
        }
        public string scid;
        private void Result_Load(object sender, EventArgs e)
        {
            fill_grid();
            try
            {
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    dataGridView1.Rows[i].Cells["Total"].Value = Convert.ToDouble(dataGridView1.Rows[i].Cells["Ben"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Eng"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Math"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Bio"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Phy"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Che"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Geo"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["His"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Com"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Dra"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Spo"].Value);
                }
            }
            catch { }
        }
        public void fill_grid()
        {
            if (sqlcon.State == ConnectionState.Open)
            {
                sqlcon.Close();
            }
            sqlcon.Open();
            SqlCommand cmd = sqlcon.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "UPDATE " + scid + "s SET Ben=0 WHERE Ben IS NULL;UPDATE " + scid + "s SET Eng=0 WHERE Eng IS NULL;UPDATE " + scid + "s SET Math=0 WHERE Math IS NULL;UPDATE " + scid + "s SET Bio=0 WHERE Bio IS NULL;UPDATE " + scid + "s SET Phy=0 WHERE Phy IS NULL;UPDATE " + scid + "s SET Che=0 WHERE Che IS NULL;UPDATE " + scid + "s SET Geo=0 WHERE Geo IS NULL;UPDATE " + scid + "s SET His=0 WHERE His IS NULL;UPDATE " + scid + "s SET Com=0 WHERE Com IS NULL;UPDATE " + scid + "s SET Dra=0 WHERE Dra IS NULL;UPDATE " + scid + "s SET Spo=0 WHERE Spo IS NULL;select SID,Sname,Sclass,Ssec,Sroll,Ben,Eng,Math,Bio,Phy,Che,Geo,His,Com,Dra,Spo,Total from " + scid + "s ;";
            cmd.ExecuteNonQuery();
            dt = new DataTable();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            SqlCommandBuilder sqlBuilder = new SqlCommandBuilder(da);
            da.Update(dt);
            fill_grid();
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    dataGridView1.Rows[i].Cells["Total"].Value = Convert.ToDouble(dataGridView1.Rows[i].Cells["Ben"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Eng"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Math"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Bio"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Phy"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Che"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Geo"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["His"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Com"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Dra"].Value) + Convert.ToDouble(dataGridView1.Rows[i].Cells["Spo"].Value);
                }
            }
            catch { }
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlcon.State == ConnectionState.Open)
                {
                    sqlcon.Close();
                }
                sqlcon.Open();
                SqlCommand cmd = sqlcon.CreateCommand();
                cmd.CommandType = CommandType.Text;
                if (checkBox1.Checked == true)
                    cmd.CommandText = "UPDATE " + scid + "s SET Ben=0 WHERE Ben IS NULL;UPDATE " + scid + "s SET Eng=0 WHERE Eng IS NULL;UPDATE " + scid + "s SET Math=0 WHERE Math IS NULL;UPDATE " + scid + "s SET Bio=0 WHERE Bio IS NULL;UPDATE " + scid + "s SET Phy=0 WHERE Phy IS NULL;UPDATE " + scid + "s SET Che=0 WHERE Che IS NULL;UPDATE " + scid + "s SET Geo=0 WHERE Geo IS NULL;UPDATE " + scid + "s SET His=0 WHERE His IS NULL;UPDATE " + scid + "s SET Com=0 WHERE Com IS NULL;UPDATE " + scid + "s SET Dra=0 WHERE Dra IS NULL;UPDATE " + scid + "s SET Spo=0 WHERE Spo IS NULL;select SID,Sname,Sclass,Ssec,Sroll,Ben,Eng,Math,Bio,Phy,Che,Geo,His,Com,Dra,Spo,Total from " + scid + "s WHERE SID='" + rjTextBox1.Texts + "' ;";
                else if (checkBox2.Checked == true && checkBox3.Checked == true)
                    cmd.CommandText = "UPDATE " + scid + "s SET Ben=0 WHERE Ben IS NULL;UPDATE " + scid + "s SET Eng=0 WHERE Eng IS NULL;UPDATE " + scid + "s SET Math=0 WHERE Math IS NULL;UPDATE " + scid + "s SET Bio=0 WHERE Bio IS NULL;UPDATE " + scid + "s SET Phy=0 WHERE Phy IS NULL;UPDATE " + scid + "s SET Che=0 WHERE Che IS NULL;UPDATE " + scid + "s SET Geo=0 WHERE Geo IS NULL;UPDATE " + scid + "s SET His=0 WHERE His IS NULL;UPDATE " + scid + "s SET Com=0 WHERE Com IS NULL;UPDATE " + scid + "s SET Dra=0 WHERE Dra IS NULL;UPDATE " + scid + "s SET Spo=0 WHERE Spo IS NULL;select SID,Sname,Sclass,Ssec,Sroll,Ben,Eng,Math,Bio,Phy,Che,Geo,His,Com,Dra,Spo,Total from " + scid + "s WHERE Sclass='" + rjTextBox2.Texts + "' and Ssec='" + rjTextBox3.Texts + "' ;";
                else if (checkBox2.Checked == true && checkBox3.Checked == false)
                    cmd.CommandText = "UPDATE " + scid + "s SET Ben=0 WHERE Ben IS NULL;UPDATE " + scid + "s SET Eng=0 WHERE Eng IS NULL;UPDATE " + scid + "s SET Math=0 WHERE Math IS NULL;UPDATE " + scid + "s SET Bio=0 WHERE Bio IS NULL;UPDATE " + scid + "s SET Phy=0 WHERE Phy IS NULL;UPDATE " + scid + "s SET Che=0 WHERE Che IS NULL;UPDATE " + scid + "s SET Geo=0 WHERE Geo IS NULL;UPDATE " + scid + "s SET His=0 WHERE His IS NULL;UPDATE " + scid + "s SET Com=0 WHERE Com IS NULL;UPDATE " + scid + "s SET Dra=0 WHERE Dra IS NULL;UPDATE " + scid + "s SET Spo=0 WHERE Spo IS NULL;select SID,Sname,Sclass,Ssec,Sroll,Ben,Eng,Math,Bio,Phy,Che,Geo,His,Com,Dra,Spo,Total from " + scid + "s WHERE Sclass='" + rjTextBox2.Texts + "' ;";
                else
                    cmd.CommandText = "UPDATE " + scid + "s SET Ben=0 WHERE Ben IS NULL;UPDATE " + scid + "s SET Eng=0 WHERE Eng IS NULL;UPDATE " + scid + "s SET Math=0 WHERE Math IS NULL;UPDATE " + scid + "s SET Bio=0 WHERE Bio IS NULL;UPDATE " + scid + "s SET Phy=0 WHERE Phy IS NULL;UPDATE " + scid + "s SET Che=0 WHERE Che IS NULL;UPDATE " + scid + "s SET Geo=0 WHERE Geo IS NULL;UPDATE " + scid + "s SET His=0 WHERE His IS NULL;UPDATE " + scid + "s SET Com=0 WHERE Com IS NULL;UPDATE " + scid + "s SET Dra=0 WHERE Dra IS NULL;UPDATE " + scid + "s SET Spo=0 WHERE Spo IS NULL;select SID,Sname,Sclass,Ssec,Sroll,Ben,Eng,Math,Bio,Phy,Che,Geo,His,Com,Dra,Spo,Total from " + scid + "s;";
                cmd.ExecuteNonQuery();
                dt = new DataTable();
                da = new SqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch { }
        }

        private void rjTextBox1__TextChanged(object sender, EventArgs e)
        {
            if (rjTextBox1.Texts.Length > 0)
            {
                checkBox1.Checked = true;
                rjTextBox2.Enabled = false;
                rjTextBox3.Enabled = false;
            }
            else
            {
                rjTextBox2.Enabled = true;
                rjTextBox3.Enabled = true;
                checkBox1.Checked = false;
            }
        }

        private void rjTextBox3__TextChanged(object sender, EventArgs e)
        {
            if (rjTextBox3.Texts.Length > 0)
            {
                checkBox3.Checked = true;
                rjTextBox1.Enabled = false;
                checkBox1.Checked = false;
            }
            else
            {
                checkBox3.Checked = false;
                rjTextBox1.Enabled = true;
            }
        }

        private void rjTextBox2__TextChanged(object sender, EventArgs e)
        {
            if (rjTextBox2.Texts.Length > 0)
            {
                checkBox2.Checked = true;
                rjTextBox1.Enabled = false;
                checkBox1.Checked = false;
                rjTextBox3.Enabled = true;

            }
            else
            {
                checkBox2.Checked = false;
                rjTextBox1.Enabled = true;
                rjTextBox3.Enabled = false;
            }
        }
    }
}
