﻿namespace School_System.user_controls
{
    partial class Teacher
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjTextBox3 = new CustomControls.RJControls.RJTextBox();
            pictureBox1 = new PictureBox();
            guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            label1 = new Label();
            guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            rjTextBox4 = new CustomControls.RJControls.RJTextBox();
            guna2ComboBox2 = new Guna.UI2.WinForms.Guna2ComboBox();
            rjButton2 = new CustomControls.RJControls.RJButton();
            dataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            Column2 = new DataGridViewTextBoxColumn();
            dataGridViewImageColumn1 = new DataGridViewImageColumn();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            rjButton3 = new CustomControls.RJControls.RJButton();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // rjTextBox1
            // 
            rjTextBox1.Anchor = AnchorStyles.Top;
            rjTextBox1.BackColor = SystemColors.Window;
            rjTextBox1.BorderColor = Color.SteelBlue;
            rjTextBox1.BorderFocusColor = Color.MidnightBlue;
            rjTextBox1.BorderRadius = 5;
            rjTextBox1.BorderSize = 2;
            rjTextBox1.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox1.Location = new Point(351, 21);
            rjTextBox1.Margin = new Padding(5, 4, 5, 4);
            rjTextBox1.Multiline = false;
            rjTextBox1.Name = "rjTextBox1";
            rjTextBox1.Padding = new Padding(10, 7, 10, 7);
            rjTextBox1.PasswordChar = false;
            rjTextBox1.PlaceholderColor = Color.DarkGray;
            rjTextBox1.PlaceholderText = "Name";
            rjTextBox1.Size = new Size(245, 35);
            rjTextBox1.TabIndex = 11;
            rjTextBox1.Texts = "";
            rjTextBox1.UnderlinedStyle = false;
            // 
            // rjButton1
            // 
            rjButton1.Anchor = AnchorStyles.Top;
            rjButton1.BackColor = Color.SteelBlue;
            rjButton1.BackgroundColor = Color.SteelBlue;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 5;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(351, 175);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(245, 36);
            rjButton1.TabIndex = 21;
            rjButton1.Text = "Import";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjTextBox3
            // 
            rjTextBox3.Anchor = AnchorStyles.Top;
            rjTextBox3.BackColor = SystemColors.Window;
            rjTextBox3.BorderColor = Color.SteelBlue;
            rjTextBox3.BorderFocusColor = Color.MidnightBlue;
            rjTextBox3.BorderRadius = 5;
            rjTextBox3.BorderSize = 2;
            rjTextBox3.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox3.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox3.Location = new Point(653, 75);
            rjTextBox3.Margin = new Padding(5, 4, 5, 4);
            rjTextBox3.Multiline = false;
            rjTextBox3.Name = "rjTextBox3";
            rjTextBox3.Padding = new Padding(10, 7, 10, 7);
            rjTextBox3.PasswordChar = false;
            rjTextBox3.PlaceholderColor = Color.DarkGray;
            rjTextBox3.PlaceholderText = "Mail ID";
            rjTextBox3.Size = new Size(245, 35);
            rjTextBox3.TabIndex = 13;
            rjTextBox3.Texts = "";
            rjTextBox3.UnderlinedStyle = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top;
            pictureBox1.BackColor = Color.White;
            pictureBox1.BackgroundImage = Properties.Resources.Screenshot_2023_04_11_082055;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(179, 21);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(148, 183);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 18;
            pictureBox1.TabStop = false;
            // 
            // guna2ComboBox1
            // 
            guna2ComboBox1.Anchor = AnchorStyles.Top;
            guna2ComboBox1.AutoCompleteCustomSource.AddRange(new string[] { "Male", "Female" });
            guna2ComboBox1.BackColor = Color.Transparent;
            guna2ComboBox1.BorderColor = Color.SteelBlue;
            guna2ComboBox1.BorderRadius = 4;
            guna2ComboBox1.BorderThickness = 2;
            guna2ComboBox1.DisplayMember = "Gender";
            guna2ComboBox1.DrawMode = DrawMode.OwnerDrawFixed;
            guna2ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            guna2ComboBox1.FocusedColor = Color.MidnightBlue;
            guna2ComboBox1.FocusedState.BorderColor = Color.MidnightBlue;
            guna2ComboBox1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2ComboBox1.ForeColor = Color.FromArgb(68, 88, 112);
            guna2ComboBox1.HoverState.BorderColor = Color.MidnightBlue;
            guna2ComboBox1.HoverState.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            guna2ComboBox1.ItemHeight = 30;
            guna2ComboBox1.Items.AddRange(new object[] { "Male", "Female" });
            guna2ComboBox1.Location = new Point(351, 124);
            guna2ComboBox1.Name = "guna2ComboBox1";
            guna2ComboBox1.Size = new Size(245, 36);
            guna2ComboBox1.TabIndex = 19;
            guna2ComboBox1.Tag = "Gender";
            guna2ComboBox1.ValueMember = "Gender";
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(653, 131);
            label1.Name = "label1";
            label1.Size = new Size(50, 22);
            label1.TabIndex = 23;
            label1.Text = "DOJ :";
            // 
            // guna2DateTimePicker1
            // 
            guna2DateTimePicker1.Anchor = AnchorStyles.Top;
            guna2DateTimePicker1.BackColor = Color.Transparent;
            guna2DateTimePicker1.BorderRadius = 5;
            guna2DateTimePicker1.Checked = true;
            guna2DateTimePicker1.FillColor = Color.LightSkyBlue;
            guna2DateTimePicker1.FocusedColor = Color.DeepSkyBlue;
            guna2DateTimePicker1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2DateTimePicker1.Format = DateTimePickerFormat.Long;
            guna2DateTimePicker1.Location = new Point(712, 125);
            guna2DateTimePicker1.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            guna2DateTimePicker1.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            guna2DateTimePicker1.Size = new Size(186, 35);
            guna2DateTimePicker1.TabIndex = 22;
            guna2DateTimePicker1.Value = new DateTime(2023, 4, 11, 0, 0, 0, 0);
            // 
            // rjTextBox4
            // 
            rjTextBox4.Anchor = AnchorStyles.Top;
            rjTextBox4.BackColor = SystemColors.Window;
            rjTextBox4.BorderColor = Color.SteelBlue;
            rjTextBox4.BorderFocusColor = Color.MidnightBlue;
            rjTextBox4.BorderRadius = 5;
            rjTextBox4.BorderSize = 2;
            rjTextBox4.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox4.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox4.Location = new Point(653, 21);
            rjTextBox4.Margin = new Padding(5, 4, 5, 4);
            rjTextBox4.Multiline = false;
            rjTextBox4.Name = "rjTextBox4";
            rjTextBox4.Padding = new Padding(10, 7, 10, 7);
            rjTextBox4.PasswordChar = false;
            rjTextBox4.PlaceholderColor = Color.DarkGray;
            rjTextBox4.PlaceholderText = "Phone Number";
            rjTextBox4.Size = new Size(245, 35);
            rjTextBox4.TabIndex = 14;
            rjTextBox4.Texts = "";
            rjTextBox4.UnderlinedStyle = false;
            // 
            // guna2ComboBox2
            // 
            guna2ComboBox2.Anchor = AnchorStyles.Top;
            guna2ComboBox2.AutoCompleteCustomSource.AddRange(new string[] { "Male", "Female" });
            guna2ComboBox2.BackColor = Color.Transparent;
            guna2ComboBox2.BorderColor = Color.SteelBlue;
            guna2ComboBox2.BorderRadius = 4;
            guna2ComboBox2.BorderThickness = 2;
            guna2ComboBox2.DisplayMember = "Gender";
            guna2ComboBox2.DrawMode = DrawMode.OwnerDrawFixed;
            guna2ComboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            guna2ComboBox2.FocusedColor = Color.MidnightBlue;
            guna2ComboBox2.FocusedState.BorderColor = Color.MidnightBlue;
            guna2ComboBox2.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2ComboBox2.ForeColor = Color.FromArgb(68, 88, 112);
            guna2ComboBox2.HoverState.BorderColor = Color.MidnightBlue;
            guna2ComboBox2.HoverState.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            guna2ComboBox2.ItemHeight = 30;
            guna2ComboBox2.Items.AddRange(new object[] { "Computer", "Mathematics", "Biology", "Geography", "History", "Physics", "English", "Bengali", "Sport", "Chemistry", "Drawing" });
            guna2ComboBox2.Location = new Point(351, 75);
            guna2ComboBox2.Name = "guna2ComboBox2";
            guna2ComboBox2.Size = new Size(245, 36);
            guna2ComboBox2.TabIndex = 24;
            guna2ComboBox2.Tag = "Gender";
            guna2ComboBox2.ValueMember = "Gender";
            // 
            // rjButton2
            // 
            rjButton2.Anchor = AnchorStyles.Top;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton2.BackgroundColor = Color.SteelBlue;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 5;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(653, 175);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(245, 36);
            rjButton2.TabIndex = 25;
            rjButton2.Text = "Browse";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(194, 200, 207);
            dataGridViewCellStyle1.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.SteelBlue;
            dataGridViewCellStyle2.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column2, dataGridViewImageColumn1, dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, Column3, Column1 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(214, 218, 223);
            dataGridViewCellStyle3.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView1.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.Location = new Point(3, 261);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.RowTemplate.Height = 100;
            dataGridView1.RowTemplate.Resizable = DataGridViewTriState.True;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
            dataGridView1.Size = new Size(1092, 416);
            dataGridView1.TabIndex = 31;
            dataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(194, 200, 207);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dataGridView1.ThemeStyle.BackColor = Color.White;
            dataGridView1.ThemeStyle.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.SteelBlue;
            dataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.ThemeStyle.HeaderStyle.Height = 40;
            dataGridView1.ThemeStyle.ReadOnly = false;
            dataGridView1.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(214, 218, 223);
            dataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ThemeStyle.RowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.RowsStyle.Height = 100;
            dataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "tid";
            Column2.HeaderText = "TID";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            // 
            // dataGridViewImageColumn1
            // 
            dataGridViewImageColumn1.DataPropertyName = "timage";
            dataGridViewImageColumn1.HeaderText = "Image";
            dataGridViewImageColumn1.Image = Properties.Resources.Screenshot_2023_04_10_170916;
            dataGridViewImageColumn1.ImageLayout = DataGridViewImageCellLayout.Zoom;
            dataGridViewImageColumn1.MinimumWidth = 6;
            dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            dataGridViewImageColumn1.Resizable = DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.DataPropertyName = "tname";
            dataGridViewTextBoxColumn1.HeaderText = "Name";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.DataPropertyName = "tgen";
            dataGridViewTextBoxColumn5.HeaderText = "Gender";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.DataPropertyName = "tmail";
            dataGridViewTextBoxColumn3.HeaderText = "Mail Id";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.DataPropertyName = "tphno";
            dataGridViewTextBoxColumn4.HeaderText = "Phone no";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // Column3
            // 
            Column3.DataPropertyName = "tsub";
            Column3.HeaderText = "Subject";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            // 
            // Column1
            // 
            Column1.DataPropertyName = "tdoj";
            Column1.HeaderText = "DOJ";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            // 
            // rjButton3
            // 
            rjButton3.Anchor = AnchorStyles.Top;
            rjButton3.BackColor = Color.SteelBlue;
            rjButton3.BackgroundColor = Color.SteelBlue;
            rjButton3.BorderColor = Color.PaleVioletRed;
            rjButton3.BorderRadius = 5;
            rjButton3.BorderSize = 0;
            rjButton3.FlatAppearance.BorderSize = 0;
            rjButton3.FlatStyle = FlatStyle.Flat;
            rjButton3.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton3.ForeColor = Color.White;
            rjButton3.Location = new Point(504, 219);
            rjButton3.Name = "rjButton3";
            rjButton3.Size = new Size(245, 36);
            rjButton3.TabIndex = 32;
            rjButton3.Text = "Remove";
            rjButton3.TextColor = Color.White;
            rjButton3.UseVisualStyleBackColor = false;
            rjButton3.Click += rjButton3_Click;
            // 
            // Teacher
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(rjButton3);
            Controls.Add(dataGridView1);
            Controls.Add(rjButton2);
            Controls.Add(guna2ComboBox2);
            Controls.Add(label1);
            Controls.Add(guna2DateTimePicker1);
            Controls.Add(rjButton1);
            Controls.Add(guna2ComboBox1);
            Controls.Add(pictureBox1);
            Controls.Add(rjTextBox4);
            Controls.Add(rjTextBox3);
            Controls.Add(rjTextBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Teacher";
            Size = new Size(1098, 680);
            Load += Teacher_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CustomControls.RJControls.RJTextBox rjTextBox1;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJTextBox rjTextBox3;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Label label1;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private CustomControls.RJControls.RJTextBox rjTextBox4;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2;
        private CustomControls.RJControls.RJButton rjButton2;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridView1;
        private CustomControls.RJControls.RJButton rjButton3;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewImageColumn dataGridViewImageColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column1;
    }
}
