﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System.user_controls
{
    public partial class Fees : UserControl
    {
        public string scid,scname,name,cls,sec,roll,gen;
        public Fees(string id)
        {
            InitializeComponent();
            scid = id;
        }

        private void Notice_Load(object sender, EventArgs e)
        {
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
            DataTable dt;
            SqlDataAdapter da;
            SqlCommand cmd = sqlcon.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select Simage,Sname,Sgen,Sclass,Ssec,Sroll from " + scid + "s where SID='" + rjTextBox1.Texts + "'";
            sqlcon.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                rjTextBox2.Texts = dr[1].ToString();
                name = dr[1].ToString();
                rjTextBox3.Texts = dr[3].ToString();
                cls = dr[3].ToString();
                rjTextBox4.Texts = dr[4].ToString();
                sec = dr[4].ToString();
                rjTextBox5.Texts = dr[5].ToString();
                roll = dr[5].ToString();
                rjTextBox6.Texts = dr[2].ToString();
                gen = dr[2].ToString();
                try
                {
                    MemoryStream ms = new MemoryStream((byte[])dr[0]);
                    pictureBox1.Image = Image.FromStream(ms);
                }
                catch { pictureBox1.Image = null; }
            }
            else
            {
                MessageBox.Show("Student Not Found");
            }
            dr.Close();
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {
            SqlConnection sqlcon = new SqlConnection(@"Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
            SqlCommand cmd = sqlcon.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select SCNAME FROM SCLOGIN where ID='" +scid+ "'";
            sqlcon.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
               scname= dr[0].ToString();
            }
            sqlcon.Close();
            MessageBox.Show(rjTextBox2.Texts);
            Fees_gen fees_Gen = new Fees_gen(scname,name,cls,sec,roll,gen);
            fees_Gen.Show();

        }
    }
}
