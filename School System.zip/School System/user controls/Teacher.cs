﻿using CustomControls.RJControls;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace School_System.user_controls
{
    public partial class Teacher : UserControl
    {
        SqlConnection sqlcon = new SqlConnection(@"Data Source=subhadippati;Initial Catalog=dbtest;User ID=sa;Password=123456");
        DataTable dt;
        SqlDataAdapter da;

        public Teacher()
        {
            InitializeComponent();
        }
        public string scid;
        public Teacher(string id)
        {
            InitializeComponent();
            scid = id;
        }

        private void Teacher_Load(object sender, EventArgs e)
        {
            guna2ComboBox1.SelectedIndex = 0;
            guna2ComboBox2.SelectedIndex = 0;
            DataGridViewImageColumn imageColumn = new DataGridViewImageColumn();
            imageColumn = (DataGridViewImageColumn)dataGridView1.Columns[1];
            imageColumn.ImageLayout = DataGridViewImageCellLayout.Zoom;
            if (sqlcon.State == ConnectionState.Open)
            {
                sqlcon.Close();
            }
            sqlcon.Open();
            fill_grid();
        }
        public void fill_grid()
        {
            SqlCommand cmd = sqlcon.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from " + scid + "t";
            cmd.ExecuteNonQuery();
            dt = new DataTable();
            da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                MemoryStream ms = new MemoryStream((byte[])dataGridView1.CurrentRow.Cells[1].Value);
                pictureBox1.Image = Image.FromStream(ms);
            }
            catch (Exception ex)
            {
            }
        }

        private void rjButton1_Click(object sender, EventArgs e)
        {
            if (rjTextBox1.Texts.Length > 0)
            {
                if (rjTextBox4.Texts.Length > 0)
                {
                    if (rjTextBox3.Texts.Length > 0)
                    {
                        newtextimport();
                    }
                    else
                    {
                        rjTextBox3.Focus();
                    }
                }
                else
                {
                    rjTextBox4.Focus();
                }
            }
            else
            {
                rjTextBox1.Focus();
            }
            SqlCommandBuilder sqlBuilder = new SqlCommandBuilder(da);
            da.Update(dt);
            pictureBox1.Image = null;
            fill_grid();
        }
        private void newtextimport()
        {

            dt = dataGridView1.DataSource as DataTable;
            DataRow row = dt.NewRow();
            row[2] = rjTextBox1.Texts.ToString();
            row[3] = guna2ComboBox1.SelectedItem.ToString();
            row[4] = rjTextBox3.Texts.ToString();
            try
            {
                row[5] = rjTextBox4.Texts.ToString();
            }
            catch (Exception ex) { row[5] = "0"; }
            row[6] = guna2ComboBox2.SelectedItem.ToString();
            row[7] = guna2DateTimePicker1.Value.Date.ToString();
            dt.Rows.Add(row);
            rjTextBox1.Texts = null;
            rjTextBox3.Texts = null;
            rjTextBox4.Texts = null;
        }

        private void rjButton3_Click(object sender, EventArgs e)
        {
            try
            {
                int rowindex = dataGridView1.CurrentCell.RowIndex;
                dataGridView1.Rows.RemoveAt(rowindex);
                SqlCommandBuilder sqlBuilder = new SqlCommandBuilder(da);
                da.Update(dt);
                fill_grid();
            }
            catch (Exception ex) { }
        }

        private void rjButton2_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Chose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif";
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.Image = Image.FromFile(openFile.FileName);
                dataGridView1[1, dataGridView1.CurrentCell.RowIndex].Value = Image.FromFile(openFile.FileName);
            }
            else
            {
                MessageBox.Show("Image is not");
            }
        }
    }
}
