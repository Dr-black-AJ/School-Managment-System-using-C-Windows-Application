﻿namespace School_System
{
    partial class Student
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            rjTextBox2 = new CustomControls.RJControls.RJTextBox();
            rjTextBox3 = new CustomControls.RJControls.RJTextBox();
            rjTextBox4 = new CustomControls.RJControls.RJTextBox();
            rjTextBox5 = new CustomControls.RJControls.RJTextBox();
            rjTextBox6 = new CustomControls.RJControls.RJTextBox();
            rjTextBox7 = new CustomControls.RJControls.RJTextBox();
            pictureBox1 = new PictureBox();
            guna2ComboBox1 = new Guna.UI2.WinForms.Guna2ComboBox();
            guna2DateTimePicker1 = new Guna.UI2.WinForms.Guna2DateTimePicker();
            rjButton1 = new CustomControls.RJControls.RJButton();
            label1 = new Label();
            rjButton2 = new CustomControls.RJControls.RJButton();
            rjButton3 = new CustomControls.RJControls.RJButton();
            dataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            Column2 = new DataGridViewTextBoxColumn();
            dataGridViewImageColumn1 = new DataGridViewImageColumn();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn7 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn8 = new DataGridViewTextBoxColumn();
            Column1 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // rjTextBox1
            // 
            rjTextBox1.Anchor = AnchorStyles.Top;
            rjTextBox1.BackColor = SystemColors.Window;
            rjTextBox1.BorderColor = Color.SteelBlue;
            rjTextBox1.BorderFocusColor = Color.MidnightBlue;
            rjTextBox1.BorderRadius = 5;
            rjTextBox1.BorderSize = 2;
            rjTextBox1.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox1.Location = new Point(294, 22);
            rjTextBox1.Margin = new Padding(4);
            rjTextBox1.Multiline = false;
            rjTextBox1.Name = "rjTextBox1";
            rjTextBox1.Padding = new Padding(10, 7, 10, 7);
            rjTextBox1.PasswordChar = false;
            rjTextBox1.PlaceholderColor = Color.DarkGray;
            rjTextBox1.PlaceholderText = "Name";
            rjTextBox1.Size = new Size(245, 35);
            rjTextBox1.TabIndex = 0;
            rjTextBox1.Texts = "";
            rjTextBox1.UnderlinedStyle = false;
            // 
            // rjTextBox2
            // 
            rjTextBox2.Anchor = AnchorStyles.Top;
            rjTextBox2.BackColor = SystemColors.Window;
            rjTextBox2.BorderColor = Color.SteelBlue;
            rjTextBox2.BorderFocusColor = Color.MidnightBlue;
            rjTextBox2.BorderRadius = 5;
            rjTextBox2.BorderSize = 2;
            rjTextBox2.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox2.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox2.Location = new Point(294, 67);
            rjTextBox2.Margin = new Padding(4);
            rjTextBox2.Multiline = false;
            rjTextBox2.Name = "rjTextBox2";
            rjTextBox2.Padding = new Padding(10, 7, 10, 7);
            rjTextBox2.PasswordChar = false;
            rjTextBox2.PlaceholderColor = Color.DarkGray;
            rjTextBox2.PlaceholderText = "Guardian  Name";
            rjTextBox2.Size = new Size(245, 35);
            rjTextBox2.TabIndex = 1;
            rjTextBox2.Texts = "";
            rjTextBox2.UnderlinedStyle = false;
            // 
            // rjTextBox3
            // 
            rjTextBox3.Anchor = AnchorStyles.Top;
            rjTextBox3.BackColor = SystemColors.Window;
            rjTextBox3.BorderColor = Color.SteelBlue;
            rjTextBox3.BorderFocusColor = Color.MidnightBlue;
            rjTextBox3.BorderRadius = 5;
            rjTextBox3.BorderSize = 2;
            rjTextBox3.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox3.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox3.Location = new Point(294, 113);
            rjTextBox3.Margin = new Padding(4);
            rjTextBox3.Multiline = false;
            rjTextBox3.Name = "rjTextBox3";
            rjTextBox3.Padding = new Padding(10, 7, 10, 7);
            rjTextBox3.PasswordChar = false;
            rjTextBox3.PlaceholderColor = Color.DarkGray;
            rjTextBox3.PlaceholderText = "Mail ID";
            rjTextBox3.Size = new Size(245, 35);
            rjTextBox3.TabIndex = 2;
            rjTextBox3.Texts = "";
            rjTextBox3.UnderlinedStyle = false;
            // 
            // rjTextBox4
            // 
            rjTextBox4.Anchor = AnchorStyles.Top;
            rjTextBox4.BackColor = SystemColors.Window;
            rjTextBox4.BorderColor = Color.SteelBlue;
            rjTextBox4.BorderFocusColor = Color.MidnightBlue;
            rjTextBox4.BorderRadius = 5;
            rjTextBox4.BorderSize = 2;
            rjTextBox4.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox4.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox4.Location = new Point(294, 160);
            rjTextBox4.Margin = new Padding(4);
            rjTextBox4.Multiline = false;
            rjTextBox4.Name = "rjTextBox4";
            rjTextBox4.Padding = new Padding(10, 7, 10, 7);
            rjTextBox4.PasswordChar = false;
            rjTextBox4.PlaceholderColor = Color.DarkGray;
            rjTextBox4.PlaceholderText = "Phone Number";
            rjTextBox4.Size = new Size(245, 35);
            rjTextBox4.TabIndex = 3;
            rjTextBox4.Texts = "";
            rjTextBox4.UnderlinedStyle = false;
            // 
            // rjTextBox5
            // 
            rjTextBox5.Anchor = AnchorStyles.Top;
            rjTextBox5.BackColor = SystemColors.Window;
            rjTextBox5.BorderColor = Color.SteelBlue;
            rjTextBox5.BorderFocusColor = Color.MidnightBlue;
            rjTextBox5.BorderRadius = 5;
            rjTextBox5.BorderSize = 2;
            rjTextBox5.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox5.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox5.Location = new Point(636, 67);
            rjTextBox5.Margin = new Padding(4);
            rjTextBox5.Multiline = false;
            rjTextBox5.Name = "rjTextBox5";
            rjTextBox5.Padding = new Padding(10, 7, 10, 7);
            rjTextBox5.PasswordChar = false;
            rjTextBox5.PlaceholderColor = Color.DarkGray;
            rjTextBox5.PlaceholderText = "Class";
            rjTextBox5.Size = new Size(245, 35);
            rjTextBox5.TabIndex = 6;
            rjTextBox5.Texts = "";
            rjTextBox5.UnderlinedStyle = false;
            // 
            // rjTextBox6
            // 
            rjTextBox6.Anchor = AnchorStyles.Top;
            rjTextBox6.BackColor = SystemColors.Window;
            rjTextBox6.BorderColor = Color.SteelBlue;
            rjTextBox6.BorderFocusColor = Color.MidnightBlue;
            rjTextBox6.BorderRadius = 5;
            rjTextBox6.BorderSize = 2;
            rjTextBox6.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox6.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox6.Location = new Point(636, 112);
            rjTextBox6.Margin = new Padding(4);
            rjTextBox6.Multiline = false;
            rjTextBox6.Name = "rjTextBox6";
            rjTextBox6.Padding = new Padding(10, 7, 10, 7);
            rjTextBox6.PasswordChar = false;
            rjTextBox6.PlaceholderColor = Color.DarkGray;
            rjTextBox6.PlaceholderText = "Section";
            rjTextBox6.Size = new Size(245, 35);
            rjTextBox6.TabIndex = 7;
            rjTextBox6.Texts = "";
            rjTextBox6.UnderlinedStyle = false;
            // 
            // rjTextBox7
            // 
            rjTextBox7.Anchor = AnchorStyles.Top;
            rjTextBox7.BackColor = SystemColors.Window;
            rjTextBox7.BorderColor = Color.SteelBlue;
            rjTextBox7.BorderFocusColor = Color.MidnightBlue;
            rjTextBox7.BorderRadius = 5;
            rjTextBox7.BorderSize = 2;
            rjTextBox7.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox7.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox7.Location = new Point(636, 160);
            rjTextBox7.Margin = new Padding(4);
            rjTextBox7.Multiline = false;
            rjTextBox7.Name = "rjTextBox7";
            rjTextBox7.Padding = new Padding(10, 7, 10, 7);
            rjTextBox7.PasswordChar = false;
            rjTextBox7.PlaceholderColor = Color.DarkGray;
            rjTextBox7.PlaceholderText = "Roll no";
            rjTextBox7.Size = new Size(245, 35);
            rjTextBox7.TabIndex = 8;
            rjTextBox7.Texts = "";
            rjTextBox7.UnderlinedStyle = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Anchor = AnchorStyles.Top;
            pictureBox1.BackColor = Color.White;
            pictureBox1.BackgroundImage = Properties.Resources.Screenshot_2023_04_10_170916;
            pictureBox1.BackgroundImageLayout = ImageLayout.Stretch;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(123, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(148, 183);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // guna2ComboBox1
            // 
            guna2ComboBox1.Anchor = AnchorStyles.Top;
            guna2ComboBox1.AutoCompleteCustomSource.AddRange(new string[] { "Male", "Female" });
            guna2ComboBox1.BackColor = Color.Transparent;
            guna2ComboBox1.BorderColor = Color.SteelBlue;
            guna2ComboBox1.BorderRadius = 4;
            guna2ComboBox1.BorderThickness = 2;
            guna2ComboBox1.DisplayMember = "Gender";
            guna2ComboBox1.DrawMode = DrawMode.OwnerDrawFixed;
            guna2ComboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            guna2ComboBox1.FocusedColor = Color.MidnightBlue;
            guna2ComboBox1.FocusedState.BorderColor = Color.MidnightBlue;
            guna2ComboBox1.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2ComboBox1.ForeColor = Color.FromArgb(68, 88, 112);
            guna2ComboBox1.HoverState.BorderColor = Color.MidnightBlue;
            guna2ComboBox1.HoverState.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            guna2ComboBox1.ItemHeight = 30;
            guna2ComboBox1.Items.AddRange(new object[] { "Male", "Female" });
            guna2ComboBox1.Location = new Point(636, 22);
            guna2ComboBox1.Name = "guna2ComboBox1";
            guna2ComboBox1.Size = new Size(245, 36);
            guna2ComboBox1.TabIndex = 5;
            guna2ComboBox1.Tag = "Gender";
            guna2ComboBox1.ValueMember = "Gender";
            // 
            // guna2DateTimePicker1
            // 
            guna2DateTimePicker1.Anchor = AnchorStyles.Top;
            guna2DateTimePicker1.BackColor = Color.Transparent;
            guna2DateTimePicker1.BorderRadius = 5;
            guna2DateTimePicker1.Checked = true;
            guna2DateTimePicker1.FillColor = Color.LightSkyBlue;
            guna2DateTimePicker1.FocusedColor = Color.DeepSkyBlue;
            guna2DateTimePicker1.Font = new Font("Arial", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2DateTimePicker1.Format = DateTimePickerFormat.Long;
            guna2DateTimePicker1.Location = new Point(353, 202);
            guna2DateTimePicker1.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            guna2DateTimePicker1.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            guna2DateTimePicker1.Name = "guna2DateTimePicker1";
            guna2DateTimePicker1.Size = new Size(186, 35);
            guna2DateTimePicker1.TabIndex = 4;
            guna2DateTimePicker1.Value = new DateTime(2023, 4, 10, 17, 21, 30, 0);
            // 
            // rjButton1
            // 
            rjButton1.Anchor = AnchorStyles.Top;
            rjButton1.BackColor = Color.SteelBlue;
            rjButton1.BackgroundColor = Color.SteelBlue;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 5;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(636, 202);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(245, 36);
            rjButton1.TabIndex = 9;
            rjButton1.Text = "Import";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(294, 208);
            label1.Name = "label1";
            label1.Size = new Size(53, 22);
            label1.TabIndex = 11;
            label1.Text = "DOB :";
            // 
            // rjButton2
            // 
            rjButton2.Anchor = AnchorStyles.Top;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton2.BackgroundColor = Color.SteelBlue;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 5;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(298, 243);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(245, 36);
            rjButton2.TabIndex = 28;
            rjButton2.Text = "Browes";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // rjButton3
            // 
            rjButton3.Anchor = AnchorStyles.Top;
            rjButton3.BackColor = Color.SteelBlue;
            rjButton3.BackgroundColor = Color.SteelBlue;
            rjButton3.BorderColor = Color.PaleVioletRed;
            rjButton3.BorderRadius = 5;
            rjButton3.BorderSize = 0;
            rjButton3.FlatAppearance.BorderSize = 0;
            rjButton3.FlatStyle = FlatStyle.Flat;
            rjButton3.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton3.ForeColor = Color.White;
            rjButton3.Location = new Point(636, 244);
            rjButton3.Name = "rjButton3";
            rjButton3.Size = new Size(245, 36);
            rjButton3.TabIndex = 29;
            rjButton3.Text = "Remove";
            rjButton3.TextColor = Color.White;
            rjButton3.UseVisualStyleBackColor = false;
            rjButton3.Click += rjButton3_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(194, 200, 207);
            dataGridViewCellStyle1.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.SteelBlue;
            dataGridViewCellStyle2.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column2, dataGridViewImageColumn1, dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7, dataGridViewTextBoxColumn8, Column1 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(214, 218, 223);
            dataGridViewCellStyle3.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView1.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.Location = new Point(3, 305);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.RowTemplate.Height = 100;
            dataGridView1.RowTemplate.Resizable = DataGridViewTriState.True;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
            dataGridView1.Size = new Size(1092, 372);
            dataGridView1.TabIndex = 30;
            dataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(194, 200, 207);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dataGridView1.ThemeStyle.BackColor = Color.White;
            dataGridView1.ThemeStyle.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.SteelBlue;
            dataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.ThemeStyle.HeaderStyle.Height = 40;
            dataGridView1.ThemeStyle.ReadOnly = false;
            dataGridView1.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(214, 218, 223);
            dataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ThemeStyle.RowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.RowsStyle.Height = 100;
            dataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "SID";
            Column2.HeaderText = "SID";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            // 
            // dataGridViewImageColumn1
            // 
            dataGridViewImageColumn1.DataPropertyName = "Simage";
            dataGridViewImageColumn1.HeaderText = "Image";
            dataGridViewImageColumn1.Image = Properties.Resources.Screenshot_2023_04_10_170916;
            dataGridViewImageColumn1.ImageLayout = DataGridViewImageCellLayout.Zoom;
            dataGridViewImageColumn1.MinimumWidth = 6;
            dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            dataGridViewImageColumn1.Resizable = DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.DataPropertyName = "Sname";
            dataGridViewTextBoxColumn1.HeaderText = "Name";
            dataGridViewTextBoxColumn1.MinimumWidth = 6;
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.DataPropertyName = "Sgardian";
            dataGridViewTextBoxColumn2.HeaderText = "Guardian";
            dataGridViewTextBoxColumn2.MinimumWidth = 6;
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.DataPropertyName = "Smail";
            dataGridViewTextBoxColumn3.HeaderText = "Mail Id";
            dataGridViewTextBoxColumn3.MinimumWidth = 6;
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.DataPropertyName = "Sphno";
            dataGridViewTextBoxColumn4.HeaderText = "Phone no";
            dataGridViewTextBoxColumn4.MinimumWidth = 6;
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.DataPropertyName = "Sgen";
            dataGridViewTextBoxColumn5.HeaderText = "Gender";
            dataGridViewTextBoxColumn5.MinimumWidth = 6;
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.DataPropertyName = "Sclass";
            dataGridViewTextBoxColumn6.HeaderText = "Class";
            dataGridViewTextBoxColumn6.MinimumWidth = 6;
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewTextBoxColumn7.DataPropertyName = "Ssec";
            dataGridViewTextBoxColumn7.HeaderText = "Section";
            dataGridViewTextBoxColumn7.MinimumWidth = 6;
            dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewTextBoxColumn8.DataPropertyName = "Sroll";
            dataGridViewTextBoxColumn8.HeaderText = "Roll";
            dataGridViewTextBoxColumn8.MinimumWidth = 6;
            dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Sbod";
            Column1.HeaderText = "BOD";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            // 
            // Student
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(dataGridView1);
            Controls.Add(rjButton3);
            Controls.Add(rjButton2);
            Controls.Add(label1);
            Controls.Add(rjButton1);
            Controls.Add(guna2DateTimePicker1);
            Controls.Add(guna2ComboBox1);
            Controls.Add(pictureBox1);
            Controls.Add(rjTextBox7);
            Controls.Add(rjTextBox6);
            Controls.Add(rjTextBox5);
            Controls.Add(rjTextBox4);
            Controls.Add(rjTextBox3);
            Controls.Add(rjTextBox2);
            Controls.Add(rjTextBox1);
            ForeColor = Color.White;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Student";
            Size = new Size(1098, 680);
            Load += Student_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CustomControls.RJControls.RJTextBox rjTextBox1;
        private CustomControls.RJControls.RJTextBox rjTextBox2;
        private CustomControls.RJControls.RJTextBox rjTextBox3;
        private CustomControls.RJControls.RJTextBox rjTextBox4;
        private CustomControls.RJControls.RJTextBox rjTextBox5;
        private CustomControls.RJControls.RJTextBox rjTextBox6;
        private CustomControls.RJControls.RJTextBox rjTextBox7;
        private PictureBox pictureBox1;
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox1;
        private Guna.UI2.WinForms.Guna2DateTimePicker guna2DateTimePicker1;
        private CustomControls.RJControls.RJButton rjButton1;
        private Label label1;
        private CustomControls.RJControls.RJButton rjButton2;
        private CustomControls.RJControls.RJButton rjButton3;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewImageColumn dataGridViewImageColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private DataGridViewTextBoxColumn Column1;
    }
}
