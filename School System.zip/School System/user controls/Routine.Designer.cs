﻿namespace School_System.user_controls
{
    partial class Routine
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            guna2ComboBox2 = new Guna.UI2.WinForms.Guna2ComboBox();
            dataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            Day = new DataGridViewTextBoxColumn();
            p1 = new DataGridViewTextBoxColumn();
            t1 = new DataGridViewTextBoxColumn();
            p2 = new DataGridViewTextBoxColumn();
            t2 = new DataGridViewTextBoxColumn();
            p3 = new DataGridViewTextBoxColumn();
            t3 = new DataGridViewTextBoxColumn();
            p4 = new DataGridViewTextBoxColumn();
            t4 = new DataGridViewTextBoxColumn();
            p5 = new DataGridViewTextBoxColumn();
            t5 = new DataGridViewTextBoxColumn();
            p6 = new DataGridViewTextBoxColumn();
            t6 = new DataGridViewTextBoxColumn();
            p7 = new DataGridViewTextBoxColumn();
            t7 = new DataGridViewTextBoxColumn();
            rjButton2 = new CustomControls.RJControls.RJButton();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // guna2ComboBox2
            // 
            guna2ComboBox2.Anchor = AnchorStyles.Top;
            guna2ComboBox2.AutoCompleteCustomSource.AddRange(new string[] { "Male", "Female" });
            guna2ComboBox2.BackColor = Color.Transparent;
            guna2ComboBox2.BorderColor = Color.SteelBlue;
            guna2ComboBox2.BorderRadius = 4;
            guna2ComboBox2.BorderThickness = 2;
            guna2ComboBox2.DisplayMember = "Gender";
            guna2ComboBox2.DrawMode = DrawMode.OwnerDrawFixed;
            guna2ComboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            guna2ComboBox2.FocusedColor = Color.MidnightBlue;
            guna2ComboBox2.FocusedState.BorderColor = Color.MidnightBlue;
            guna2ComboBox2.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            guna2ComboBox2.ForeColor = Color.FromArgb(68, 88, 112);
            guna2ComboBox2.HoverState.BorderColor = Color.MidnightBlue;
            guna2ComboBox2.HoverState.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            guna2ComboBox2.ItemHeight = 30;
            guna2ComboBox2.Items.AddRange(new object[] { "5", "6", "7", "8", "9", "10" });
            guna2ComboBox2.Location = new Point(89, 32);
            guna2ComboBox2.Name = "guna2ComboBox2";
            guna2ComboBox2.Size = new Size(151, 36);
            guna2ComboBox2.TabIndex = 26;
            guna2ComboBox2.Tag = "Gender";
            guna2ComboBox2.ValueMember = "Gender";
            guna2ComboBox2.SelectedIndexChanged += guna2ComboBox2_SelectedIndexChanged;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(194, 200, 207);
            dataGridViewCellStyle1.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.SteelBlue;
            dataGridViewCellStyle2.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Day, p1, t1, p2, t2, p3, t3, p4, t4, p5, t5, p6, t6, p7, t7 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(214, 218, 223);
            dataGridViewCellStyle3.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView1.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.Location = new Point(3, 154);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.RowTemplate.Height = 100;
            dataGridView1.RowTemplate.Resizable = DataGridViewTriState.True;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
            dataGridView1.Size = new Size(1092, 523);
            dataGridView1.TabIndex = 31;
            dataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(194, 200, 207);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dataGridView1.ThemeStyle.BackColor = Color.White;
            dataGridView1.ThemeStyle.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.SteelBlue;
            dataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.ThemeStyle.HeaderStyle.Height = 40;
            dataGridView1.ThemeStyle.ReadOnly = false;
            dataGridView1.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(214, 218, 223);
            dataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ThemeStyle.RowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.RowsStyle.Height = 100;
            dataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            // 
            // Day
            // 
            Day.DataPropertyName = "Day";
            Day.HeaderText = "Day";
            Day.MinimumWidth = 6;
            Day.Name = "Day";
            // 
            // p1
            // 
            p1.DataPropertyName = "p1";
            p1.HeaderText = "p1";
            p1.MinimumWidth = 6;
            p1.Name = "p1";
            // 
            // t1
            // 
            t1.DataPropertyName = "t1";
            t1.HeaderText = "t1";
            t1.MinimumWidth = 6;
            t1.Name = "t1";
            // 
            // p2
            // 
            p2.DataPropertyName = "p2";
            p2.HeaderText = "p2";
            p2.MinimumWidth = 6;
            p2.Name = "p2";
            // 
            // t2
            // 
            t2.DataPropertyName = "t2";
            t2.HeaderText = "t2";
            t2.MinimumWidth = 6;
            t2.Name = "t2";
            // 
            // p3
            // 
            p3.DataPropertyName = "p3";
            p3.HeaderText = "p3";
            p3.MinimumWidth = 6;
            p3.Name = "p3";
            // 
            // t3
            // 
            t3.DataPropertyName = "t3";
            t3.HeaderText = "t3";
            t3.MinimumWidth = 6;
            t3.Name = "t3";
            // 
            // p4
            // 
            p4.DataPropertyName = "p4";
            p4.HeaderText = "p4";
            p4.MinimumWidth = 6;
            p4.Name = "p4";
            // 
            // t4
            // 
            t4.DataPropertyName = "t4";
            t4.HeaderText = "t4";
            t4.MinimumWidth = 6;
            t4.Name = "t4";
            // 
            // p5
            // 
            p5.DataPropertyName = "p5";
            p5.HeaderText = "p5";
            p5.MinimumWidth = 6;
            p5.Name = "p5";
            // 
            // t5
            // 
            t5.DataPropertyName = "t5";
            t5.HeaderText = "t5";
            t5.MinimumWidth = 6;
            t5.Name = "t5";
            // 
            // p6
            // 
            p6.DataPropertyName = "p6";
            p6.HeaderText = "p6";
            p6.MinimumWidth = 6;
            p6.Name = "p6";
            // 
            // t6
            // 
            t6.DataPropertyName = "t6";
            t6.HeaderText = "t6";
            t6.MinimumWidth = 6;
            t6.Name = "t6";
            // 
            // p7
            // 
            p7.DataPropertyName = "p7";
            p7.HeaderText = "p7";
            p7.MinimumWidth = 6;
            p7.Name = "p7";
            // 
            // t7
            // 
            t7.DataPropertyName = "t7";
            t7.HeaderText = "t7";
            t7.MinimumWidth = 6;
            t7.Name = "t7";
            // 
            // rjButton2
            // 
            rjButton2.Anchor = AnchorStyles.Top;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton2.BackgroundColor = Color.SteelBlue;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 5;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(846, 32);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(151, 36);
            rjButton2.TabIndex = 32;
            rjButton2.Text = "Update";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // Routine
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(rjButton2);
            Controls.Add(dataGridView1);
            Controls.Add(guna2ComboBox2);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Routine";
            Size = new Size(1098, 680);
            Load += Routine_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2ComboBox guna2ComboBox2;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridView1;
        private DataGridViewTextBoxColumn Day;
        private DataGridViewTextBoxColumn p1;
        private DataGridViewTextBoxColumn t1;
        private DataGridViewTextBoxColumn p2;
        private DataGridViewTextBoxColumn t2;
        private DataGridViewTextBoxColumn p3;
        private DataGridViewTextBoxColumn t3;
        private DataGridViewTextBoxColumn p4;
        private DataGridViewTextBoxColumn t4;
        private DataGridViewTextBoxColumn p5;
        private DataGridViewTextBoxColumn t5;
        private DataGridViewTextBoxColumn p6;
        private DataGridViewTextBoxColumn t6;
        private DataGridViewTextBoxColumn p7;
        private DataGridViewTextBoxColumn t7;
        private CustomControls.RJControls.RJButton rjButton2;
    }
}
