﻿namespace School_System.user_controls
{
    partial class Result
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            rjTextBox1 = new CustomControls.RJControls.RJTextBox();
            rjButton1 = new CustomControls.RJControls.RJButton();
            rjButton2 = new CustomControls.RJControls.RJButton();
            dataGridView1 = new Guna.UI2.WinForms.Guna2DataGridView();
            SID = new DataGridViewTextBoxColumn();
            Sname = new DataGridViewTextBoxColumn();
            Sclass = new DataGridViewTextBoxColumn();
            Ssec = new DataGridViewTextBoxColumn();
            Sroll = new DataGridViewTextBoxColumn();
            Ben = new DataGridViewTextBoxColumn();
            Eng = new DataGridViewTextBoxColumn();
            Math = new DataGridViewTextBoxColumn();
            Bio = new DataGridViewTextBoxColumn();
            Phy = new DataGridViewTextBoxColumn();
            Che = new DataGridViewTextBoxColumn();
            Geo = new DataGridViewTextBoxColumn();
            His = new DataGridViewTextBoxColumn();
            Com = new DataGridViewTextBoxColumn();
            Dra = new DataGridViewTextBoxColumn();
            Spo = new DataGridViewTextBoxColumn();
            Total = new DataGridViewTextBoxColumn();
            rjTextBox2 = new CustomControls.RJControls.RJTextBox();
            rjTextBox3 = new CustomControls.RJControls.RJTextBox();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // rjTextBox1
            // 
            rjTextBox1.Anchor = AnchorStyles.Top;
            rjTextBox1.BackColor = SystemColors.Window;
            rjTextBox1.BorderColor = Color.SteelBlue;
            rjTextBox1.BorderFocusColor = Color.MidnightBlue;
            rjTextBox1.BorderRadius = 5;
            rjTextBox1.BorderSize = 2;
            rjTextBox1.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox1.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox1.Location = new Point(238, 44);
            rjTextBox1.Margin = new Padding(4);
            rjTextBox1.Multiline = false;
            rjTextBox1.Name = "rjTextBox1";
            rjTextBox1.Padding = new Padding(10, 7, 10, 7);
            rjTextBox1.PasswordChar = false;
            rjTextBox1.PlaceholderColor = Color.DarkGray;
            rjTextBox1.PlaceholderText = "Student Id";
            rjTextBox1.Size = new Size(245, 35);
            rjTextBox1.TabIndex = 7;
            rjTextBox1.Texts = "";
            rjTextBox1.UnderlinedStyle = false;
            rjTextBox1._TextChanged += rjTextBox1__TextChanged;
            // 
            // rjButton1
            // 
            rjButton1.Anchor = AnchorStyles.Top;
            rjButton1.BackColor = Color.SteelBlue;
            rjButton1.BackgroundColor = Color.SteelBlue;
            rjButton1.BorderColor = Color.PaleVioletRed;
            rjButton1.BorderRadius = 5;
            rjButton1.BorderSize = 0;
            rjButton1.FlatAppearance.BorderSize = 0;
            rjButton1.FlatStyle = FlatStyle.Flat;
            rjButton1.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton1.ForeColor = Color.White;
            rjButton1.Location = new Point(238, 180);
            rjButton1.Name = "rjButton1";
            rjButton1.Size = new Size(245, 36);
            rjButton1.TabIndex = 22;
            rjButton1.Text = "Search ";
            rjButton1.TextColor = Color.White;
            rjButton1.UseVisualStyleBackColor = false;
            rjButton1.Click += rjButton1_Click;
            // 
            // rjButton2
            // 
            rjButton2.Anchor = AnchorStyles.Top;
            rjButton2.BackColor = Color.SteelBlue;
            rjButton2.BackgroundColor = Color.SteelBlue;
            rjButton2.BorderColor = Color.PaleVioletRed;
            rjButton2.BorderRadius = 5;
            rjButton2.BorderSize = 0;
            rjButton2.FlatAppearance.BorderSize = 0;
            rjButton2.FlatStyle = FlatStyle.Flat;
            rjButton2.Font = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            rjButton2.ForeColor = Color.White;
            rjButton2.Location = new Point(651, 180);
            rjButton2.Name = "rjButton2";
            rjButton2.Size = new Size(245, 36);
            rjButton2.TabIndex = 24;
            rjButton2.Text = "Save";
            rjButton2.TextColor = Color.White;
            rjButton2.UseVisualStyleBackColor = false;
            rjButton2.Click += rjButton2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToOrderColumns = true;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(194, 200, 207);
            dataGridViewCellStyle1.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.SteelBlue;
            dataGridViewCellStyle2.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { SID, Sname, Sclass, Ssec, Sroll, Ben, Eng, Math, Bio, Phy, Che, Geo, His, Com, Dra, Spo, Total });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(214, 218, 223);
            dataGridViewCellStyle3.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridViewCellStyle3.SelectionForeColor = Color.Black;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView1.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.Location = new Point(3, 310);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.RowHeadersWidth = 51;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.RowTemplate.Height = 100;
            dataGridView1.RowTemplate.Resizable = DataGridViewTriState.True;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.RowHeaderSelect;
            dataGridView1.Size = new Size(1092, 367);
            dataGridView1.TabIndex = 32;
            dataGridView1.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.WetAsphalt;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.BackColor = Color.FromArgb(194, 200, 207);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dataGridView1.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dataGridView1.ThemeStyle.BackColor = Color.White;
            dataGridView1.ThemeStyle.GridColor = Color.FromArgb(193, 199, 206);
            dataGridView1.ThemeStyle.HeaderStyle.BackColor = Color.SteelBlue;
            dataGridView1.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dataGridView1.ThemeStyle.HeaderStyle.Font = new Font("Arial Narrow", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dataGridView1.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridView1.ThemeStyle.HeaderStyle.Height = 40;
            dataGridView1.ThemeStyle.ReadOnly = false;
            dataGridView1.ThemeStyle.RowsStyle.BackColor = Color.FromArgb(214, 218, 223);
            dataGridView1.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridView1.ThemeStyle.RowsStyle.Font = new Font("Arial", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridView1.ThemeStyle.RowsStyle.ForeColor = Color.Black;
            dataGridView1.ThemeStyle.RowsStyle.Height = 100;
            dataGridView1.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(119, 133, 147);
            dataGridView1.ThemeStyle.RowsStyle.SelectionForeColor = Color.Black;
            dataGridView1.CellEndEdit += dataGridView1_CellEndEdit;
            // 
            // SID
            // 
            SID.DataPropertyName = "SID";
            SID.HeaderText = "SID";
            SID.MinimumWidth = 6;
            SID.Name = "SID";
            // 
            // Sname
            // 
            Sname.DataPropertyName = "Sname";
            Sname.HeaderText = "Name";
            Sname.MinimumWidth = 6;
            Sname.Name = "Sname";
            // 
            // Sclass
            // 
            Sclass.DataPropertyName = "Sclass";
            Sclass.HeaderText = "Class";
            Sclass.MinimumWidth = 6;
            Sclass.Name = "Sclass";
            // 
            // Ssec
            // 
            Ssec.DataPropertyName = "Ssec";
            Ssec.HeaderText = "Sec";
            Ssec.MinimumWidth = 6;
            Ssec.Name = "Ssec";
            // 
            // Sroll
            // 
            Sroll.DataPropertyName = "Sroll";
            Sroll.HeaderText = "Roll";
            Sroll.MinimumWidth = 6;
            Sroll.Name = "Sroll";
            // 
            // Ben
            // 
            Ben.DataPropertyName = "Ben";
            Ben.HeaderText = "Bengali";
            Ben.MinimumWidth = 6;
            Ben.Name = "Ben";
            // 
            // Eng
            // 
            Eng.DataPropertyName = "Eng";
            Eng.HeaderText = "English";
            Eng.MinimumWidth = 6;
            Eng.Name = "Eng";
            // 
            // Math
            // 
            Math.DataPropertyName = "Math";
            Math.HeaderText = "Mathematics";
            Math.MinimumWidth = 6;
            Math.Name = "Math";
            // 
            // Bio
            // 
            Bio.DataPropertyName = "Bio";
            Bio.HeaderText = "Biology";
            Bio.MinimumWidth = 6;
            Bio.Name = "Bio";
            // 
            // Phy
            // 
            Phy.DataPropertyName = "Phy";
            Phy.HeaderText = "Physics";
            Phy.MinimumWidth = 6;
            Phy.Name = "Phy";
            // 
            // Che
            // 
            Che.DataPropertyName = "Che";
            Che.HeaderText = "Chemistry";
            Che.MinimumWidth = 6;
            Che.Name = "Che";
            // 
            // Geo
            // 
            Geo.DataPropertyName = "Geo";
            Geo.HeaderText = "Geography";
            Geo.MinimumWidth = 6;
            Geo.Name = "Geo";
            // 
            // His
            // 
            His.DataPropertyName = "His";
            His.HeaderText = "History";
            His.MinimumWidth = 6;
            His.Name = "His";
            // 
            // Com
            // 
            Com.DataPropertyName = "Com";
            Com.HeaderText = "Computer";
            Com.MinimumWidth = 6;
            Com.Name = "Com";
            // 
            // Dra
            // 
            Dra.DataPropertyName = "Dra";
            Dra.HeaderText = "Drawing";
            Dra.MinimumWidth = 6;
            Dra.Name = "Dra";
            // 
            // Spo
            // 
            Spo.DataPropertyName = "Spo";
            Spo.HeaderText = "Sport";
            Spo.MinimumWidth = 6;
            Spo.Name = "Spo";
            // 
            // Total
            // 
            Total.DataPropertyName = "Total";
            Total.HeaderText = "Total";
            Total.MinimumWidth = 6;
            Total.Name = "Total";
            // 
            // rjTextBox2
            // 
            rjTextBox2.Anchor = AnchorStyles.Top;
            rjTextBox2.BackColor = SystemColors.Window;
            rjTextBox2.BorderColor = Color.SteelBlue;
            rjTextBox2.BorderFocusColor = Color.MidnightBlue;
            rjTextBox2.BorderRadius = 5;
            rjTextBox2.BorderSize = 2;
            rjTextBox2.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox2.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox2.Location = new Point(238, 87);
            rjTextBox2.Margin = new Padding(4);
            rjTextBox2.Multiline = false;
            rjTextBox2.Name = "rjTextBox2";
            rjTextBox2.Padding = new Padding(10, 7, 10, 7);
            rjTextBox2.PasswordChar = false;
            rjTextBox2.PlaceholderColor = Color.DarkGray;
            rjTextBox2.PlaceholderText = "Class";
            rjTextBox2.Size = new Size(245, 35);
            rjTextBox2.TabIndex = 33;
            rjTextBox2.Texts = "";
            rjTextBox2.UnderlinedStyle = false;
            rjTextBox2._TextChanged += rjTextBox2__TextChanged;
            // 
            // rjTextBox3
            // 
            rjTextBox3.Anchor = AnchorStyles.Top;
            rjTextBox3.BackColor = SystemColors.Window;
            rjTextBox3.BorderColor = Color.SteelBlue;
            rjTextBox3.BorderFocusColor = Color.MidnightBlue;
            rjTextBox3.BorderRadius = 5;
            rjTextBox3.BorderSize = 2;
            rjTextBox3.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
            rjTextBox3.ForeColor = Color.FromArgb(64, 64, 64);
            rjTextBox3.Location = new Point(238, 130);
            rjTextBox3.Margin = new Padding(4);
            rjTextBox3.Multiline = false;
            rjTextBox3.Name = "rjTextBox3";
            rjTextBox3.Padding = new Padding(10, 7, 10, 7);
            rjTextBox3.PasswordChar = false;
            rjTextBox3.PlaceholderColor = Color.DarkGray;
            rjTextBox3.PlaceholderText = "Section";
            rjTextBox3.Size = new Size(245, 35);
            rjTextBox3.TabIndex = 34;
            rjTextBox3.Texts = "";
            rjTextBox3.UnderlinedStyle = false;
            rjTextBox3._TextChanged += rjTextBox3__TextChanged;
            // 
            // checkBox1
            // 
            checkBox1.Anchor = AnchorStyles.Top;
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(490, 55);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(18, 17);
            checkBox1.TabIndex = 36;
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.Anchor = AnchorStyles.Top;
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(490, 97);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(18, 17);
            checkBox2.TabIndex = 37;
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.Anchor = AnchorStyles.Top;
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(490, 138);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(18, 17);
            checkBox3.TabIndex = 38;
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // Result
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(rjTextBox3);
            Controls.Add(rjTextBox2);
            Controls.Add(dataGridView1);
            Controls.Add(rjButton2);
            Controls.Add(rjButton1);
            Controls.Add(rjTextBox1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Result";
            Size = new Size(1098, 680);
            Load += Result_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private CustomControls.RJControls.RJTextBox rjTextBox1;
        private CustomControls.RJControls.RJButton rjButton1;
        private CustomControls.RJControls.RJButton rjButton2;
        private Guna.UI2.WinForms.Guna2DataGridView dataGridView1;
        private DataGridViewTextBoxColumn SID;
        private DataGridViewTextBoxColumn Sname;
        private DataGridViewTextBoxColumn Sclass;
        private DataGridViewTextBoxColumn Ssec;
        private DataGridViewTextBoxColumn Sroll;
        private DataGridViewTextBoxColumn Ben;
        private DataGridViewTextBoxColumn Eng;
        private DataGridViewTextBoxColumn Math;
        private DataGridViewTextBoxColumn Bio;
        private DataGridViewTextBoxColumn Phy;
        private DataGridViewTextBoxColumn Che;
        private DataGridViewTextBoxColumn Geo;
        private DataGridViewTextBoxColumn His;
        private DataGridViewTextBoxColumn Com;
        private DataGridViewTextBoxColumn Dra;
        private DataGridViewTextBoxColumn Spo;
        private DataGridViewTextBoxColumn Total;
        private CustomControls.RJControls.RJTextBox rjTextBox2;
        private CustomControls.RJControls.RJTextBox rjTextBox3;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
    }
}
