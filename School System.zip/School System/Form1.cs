namespace School_System
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            guna2ShadowPanel2.Width += 3;
            if (guna2ShadowPanel2.Width >= 570)
            {
                timer1.Stop();
                LoginPage nu = new LoginPage();
                nu.Show();
                this.Hide();
            }
        }
    }
}